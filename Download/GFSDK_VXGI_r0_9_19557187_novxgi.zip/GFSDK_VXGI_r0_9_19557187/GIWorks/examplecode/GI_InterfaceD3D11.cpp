/* 
* Copyright (c) 2012-2015, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#include "GI_InterfaceD3D11.h"

#include <nvapi.h>
#ifdef _WIN64
#pragma comment(lib, "nvapi64.lib")
#else
#pragma comment(lib, "nvapi.lib")
#endif

#define CHECK_ERROR(expr, msg) if (!(expr)) this->signalError(__FILE__, __LINE__, msg)

#pragma warning(disable:4127) // conditional expression is constant

namespace VXGI
{
namespace Util 
{
  //convert the format to a DXGI format
  static DXGI_FORMAT getUntypedTextureFormat(TextureDesc::Format format, UINT& outPixelSizeBytes)
  {
    DXGI_FORMAT allocFormat = DXGI_FORMAT_UNKNOWN;
    switch(format)
    {
      //We prefer typeless since they can also be UAVs
    case TextureDesc::FORMAT_R32U:
      allocFormat = DXGI_FORMAT_R32_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA16F:
      allocFormat = DXGI_FORMAT_R16G16B16A16_TYPELESS;
      outPixelSizeBytes = 8;
      break;
    case TextureDesc::FORMAT_RGBA32F:
      allocFormat = DXGI_FORMAT_R32G32B32A32_TYPELESS;
      outPixelSizeBytes = 16;
      break;
    case TextureDesc::FORMAT_R32F:
      allocFormat =  DXGI_FORMAT_R32_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA8_UNORM:
      allocFormat = DXGI_FORMAT_R8G8B8A8_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_BGRA8_UNORM:
	    allocFormat = DXGI_FORMAT_B8G8R8A8_TYPELESS;
	    outPixelSizeBytes = 4;
	    break;
    case TextureDesc::FORMAT_SRGBA8_UNORM:
      allocFormat = DXGI_FORMAT_R8G8B8A8_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA16_UNORM:
      allocFormat = DXGI_FORMAT_R16G16B16A16_TYPELESS;
      outPixelSizeBytes = 8;
      break;
    case TextureDesc::FORMAT_R10G10B10A2_UNORM:
      allocFormat = DXGI_FORMAT_R10G10B10A2_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RG16F:
      allocFormat = DXGI_FORMAT_R16G16_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_D16:
      allocFormat = DXGI_FORMAT_R16_TYPELESS;
      outPixelSizeBytes = 2;
      break;
    case TextureDesc::FORMAT_D24S8:
      allocFormat = DXGI_FORMAT_R24G8_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_D32:
      allocFormat = DXGI_FORMAT_R32_TYPELESS;
      outPixelSizeBytes = 4;
      break;
    }
    return allocFormat;
  }

  static DXGI_FORMAT getTypedTextureFormat(TextureDesc::Format format, UINT& outPixelSizeBytes, bool forSRV)
  {
    DXGI_FORMAT allocFormat = DXGI_FORMAT_UNKNOWN;
    //convert the format to a DXGI format
    switch(format)
    {
      //We prefer typeless since they can also be UAVs
    case TextureDesc::FORMAT_R32U:
      allocFormat = DXGI_FORMAT_R32_UINT;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA16F:
      allocFormat = DXGI_FORMAT_R16G16B16A16_FLOAT;
      outPixelSizeBytes = 8;
      break;
    case TextureDesc::FORMAT_RGBA32F:
      allocFormat = DXGI_FORMAT_R32G32B32A32_FLOAT;
      outPixelSizeBytes = 16;
      break;
    case TextureDesc::FORMAT_R32F:
      allocFormat =  DXGI_FORMAT_R32_FLOAT;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA8_UNORM:
      allocFormat = DXGI_FORMAT_R8G8B8A8_UNORM;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_BGRA8_UNORM:
	    allocFormat = DXGI_FORMAT_B8G8R8A8_UNORM;
	    outPixelSizeBytes = 4;
	    break;
    case TextureDesc::FORMAT_SRGBA8_UNORM:
      allocFormat = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RGBA16_UNORM:
      allocFormat = DXGI_FORMAT_R16G16B16A16_UNORM;
      outPixelSizeBytes = 8;
      break;
    case TextureDesc::FORMAT_R10G10B10A2_UNORM:
      allocFormat = DXGI_FORMAT_R10G10B10A2_UNORM;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_RG16F:
      allocFormat = DXGI_FORMAT_R16G16_FLOAT;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_D16:
      allocFormat = forSRV ? DXGI_FORMAT_R16_UNORM : DXGI_FORMAT_D16_UNORM;
      outPixelSizeBytes = 2;
      break;
    case TextureDesc::FORMAT_D24S8:
      allocFormat = forSRV ? DXGI_FORMAT_R24_UNORM_X8_TYPELESS : DXGI_FORMAT_D24_UNORM_S8_UINT;
      outPixelSizeBytes = 4;
      break;
    case TextureDesc::FORMAT_D32:
      allocFormat = forSRV ? DXGI_FORMAT_R32_FLOAT : DXGI_FORMAT_D32_FLOAT;
      outPixelSizeBytes = 4;
      break;
    }
    return allocFormat;
  }

  IRendererInterfaceD3D11::~IRendererInterfaceD3D11()
  {
    if (nvapiIsInitalized)
        NvAPI_Unload();
  }

 
  IRendererInterfaceD3D11::IRendererInterfaceD3D11(IErrorCallback* errorCB, ID3D11DeviceContext* context) 
    : context(context)
    , errorCB(errorCB)
    , validateStatesWithTheSameIDAreTheSame(false)
    , nvapiIsInitalized(false)
  {
    this->context->GetDevice(&device);
#ifdef _DEBUG
    //turn this on by default in debug mode
    validateStatesWithTheSameIDAreTheSame = true;
#endif

    //We need to use NVAPI to set resource hints for SLI
    nvapiIsInitalized = NvAPI_Initialize() == NVAPI_OK;
  }
  
  TextureHandle IRendererInterfaceD3D11::createTexture(const TextureDesc& d, const void* data)
  {
    D3D11_USAGE usage = D3D11_USAGE_DEFAULT;
    UINT pixelSizeBytes = 0;
    //We prefer typeless since they can also be UAVs
    DXGI_FORMAT allocFormat = getUntypedTextureFormat(d.format, pixelSizeBytes);
    CHECK_ERROR(allocFormat != DXGI_FORMAT_UNKNOWN, "Unknown format");

    //convert the usage
    switch (d.usage)
    {
    case TextureDesc::USAGE_DEFAULT:
      usage = D3D11_USAGE_DEFAULT; 
      break;
    case TextureDesc::USAGE_DYNAMIC:
      usage = D3D11_USAGE_DYNAMIC; 
      break;
    case TextureDesc::USAGE_IMMUTABLE:
      usage = D3D11_USAGE_IMMUTABLE; 
      break;
    default:
      CHECK_ERROR(0, "Unknown usage");
    }
    //convert flags
    UINT bindFlags = D3D11_BIND_SHADER_RESOURCE;
    if (d.isRenderTarget)
      bindFlags |= (d.format == TextureDesc::FORMAT_D16 || d.format == TextureDesc::FORMAT_D24S8 || d.format == TextureDesc::FORMAT_D32) ? D3D11_BIND_DEPTH_STENCIL : D3D11_BIND_RENDER_TARGET;
    if (d.isUAV)
      bindFlags |= D3D11_BIND_UNORDERED_ACCESS;

    UINT cpuAccessFlags = 0;
    if (d.isCPUWritable)
      cpuAccessFlags |= D3D11_CPU_ACCESS_WRITE;

    D3D11_SUBRESOURCE_DATA initalData;
    initalData.pSysMem = data;
    //if we have source data, it's always tightly packed
    initalData.SysMemPitch = d.dimensions.x * pixelSizeBytes;
    initalData.SysMemSlicePitch = d.dimensions.x * d.dimensions.y * pixelSizeBytes;

    if (d.dimensions.z == 0 || d.isArray || d.isCubeMap)
    {
      //it's a 2D texture or an array
      D3D11_TEXTURE2D_DESC desc11;
      desc11.Width = (UINT)d.dimensions.x;
      desc11.Height = (UINT)d.dimensions.y;
      desc11.MipLevels = (UINT)d.mipLevels;
      //if d.isArray then d.dimensions.z is the length, otherwise it's the 3D texture depth
      desc11.ArraySize = (d.isArray || d.isCubeMap) ? (UINT)d.dimensions.z : 1;
      desc11.Format = allocFormat;
      desc11.SampleDesc.Count = (UINT)d.sampleCount;
      desc11.SampleDesc.Quality = (UINT)d.sampleQuality;
      desc11.Usage = usage;
      desc11.BindFlags = bindFlags;
      desc11.CPUAccessFlags = cpuAccessFlags;
      desc11.MiscFlags = d.isCubeMap ? D3D11_RESOURCE_MISC_TEXTURECUBE : 0;

      ComPtr<ID3D11Texture2D> newTexture;
      HRESULT r = device->CreateTexture2D(&desc11, data ? &initalData : NULL, &newTexture);
      CHECK_ERROR(SUCCEEDED(r), "Creating a texture failed");

      if (d.disableSLISync)
        disableSLIResouceSync(newTexture.Get());

      //add it to the map (passing texture desc to store a copy of it)
      return (TextureHandle)getHandleForTexture(newTexture.Get(), &d);
    }
    else
    {
      //it's a 3D texture
      D3D11_TEXTURE3D_DESC desc11;
      desc11.Width = (UINT)d.dimensions.x;
      desc11.Height = (UINT)d.dimensions.y;
      desc11.Depth = (UINT)d.dimensions.z;
      desc11.MipLevels = (UINT)d.mipLevels;
      desc11.Format = allocFormat;
      desc11.Usage = usage;
      desc11.BindFlags = bindFlags;
      desc11.CPUAccessFlags = cpuAccessFlags;
      desc11.MiscFlags = 0;

      ComPtr<ID3D11Texture3D> newTexture;
      HRESULT r = device->CreateTexture3D(&desc11, data ? &initalData : NULL, &newTexture);
      CHECK_ERROR(SUCCEEDED(r), "Creating a texture failed");
      
      if (d.disableSLISync)
        disableSLIResouceSync(newTexture.Get());

      //add it to the map  (passing texture desc to store a copy of it)
      return (TextureHandle)getHandleForTexture(newTexture.Get(), &d);
    }
  }

  TextureDesc IRendererInterfaceD3D11::describeTexture(TextureHandle t)
  {
    TextureObjectMap::value_type* handle = (TextureObjectMap::value_type*)t;
    return handle->second.textureDesc;
  }

  void IRendererInterfaceD3D11::clearTextureFloat(TextureHandle t, const Vector4f& clearColor)
  {
    TextureObjectMap::value_type* handle = (TextureObjectMap::value_type*)t;
    ID3D11UnorderedAccessView* uav = NULL;
    ID3D11RenderTargetView* rtv = NULL;
    ID3D11DepthStencilView* dsv = NULL;
    uint32_t index = 0;

    while(true)
    {
      getClearViewForTexture(handle, index++, false, uav, rtv, dsv);
      if (uav)
      {
        FLOAT values[4] = { clearColor.x, clearColor.y, clearColor.z, clearColor.w };
        context->ClearUnorderedAccessViewFloat(uav, values);
      }
      else if (rtv)
      {
        FLOAT values[4] = { clearColor.x, clearColor.y, clearColor.z, clearColor.w };
        context->ClearRenderTargetView(rtv, values);
      }
      else if (dsv)
      {
        //re-interpret .y as stencil. Maybe you don't want to do this, but we should do something.
        context->ClearDepthStencilView(dsv, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, clearColor.x, *((UINT8*)&clearColor.y));
      }
      else
      {
        break; //no more sub-views
      }
    }
  }

  void IRendererInterfaceD3D11::clearTextureUInt(TextureHandle t, const Vector4u& clearColor)
  {
    TextureObjectMap::value_type* handle = (TextureObjectMap::value_type*)t;
    ID3D11UnorderedAccessView* uav = NULL;
    ID3D11RenderTargetView* rtv = NULL;
    ID3D11DepthStencilView* dsv = NULL;
    uint32_t index = 0;

    while(true)
    {
      getClearViewForTexture(handle, index++, false, uav, rtv, dsv);
      if (uav)
      {
        UINT values[4] = { clearColor.x, clearColor.y, clearColor.z, clearColor.w };
        context->ClearUnorderedAccessViewUint(uav, values);
      }
      else if (rtv)
      {
        //This doesn't really make sense for non-zero values but we should clear it if we can
        FLOAT values[4] = { *((FLOAT*)&clearColor.x), *((FLOAT*)&clearColor.y), *((FLOAT*)&clearColor.z), *((FLOAT*)&clearColor.w) };
        context->ClearRenderTargetView(rtv, values);
      }
      else if (dsv)
      {
        //re-interpret .x as float, probably you don't want to clear dsv this way
        context->ClearDepthStencilView(dsv, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, *((FLOAT*)&clearColor.x), (UINT8)clearColor.y);
      }
      else
      {
        break; //no more sub-views
      }
    }
  }

  void IRendererInterfaceD3D11::writeTexture(TextureHandle t, uint32_t subresource, const void* data, uint32_t rowPitch, uint32_t depthPitch)
  {
    TextureObjectMap::value_type* handle = (TextureObjectMap::value_type*)t;

    ID3D11Resource* resource = handle->first.Get();

    context->UpdateSubresource(resource, subresource, NULL, data, rowPitch, depthPitch);
  }

  void IRendererInterfaceD3D11::destroyTexture(TextureHandle t)
  {
    TextureObjectMap::value_type* handle = (TextureObjectMap::value_type*)t;
    if (!handle)
      return;
    //the smart pointer class will release the texture if we are the last owner
    textures.erase(handle->first);
  }

  BufferHandle IRendererInterfaceD3D11::createBuffer(const BufferDesc& d, const void* data)
  {
    D3D11_BUFFER_DESC desc11;
    desc11.ByteWidth = (UINT)d.byteSize;
    
    //These don't map exactly, but it should be generally correct
    if (d.isCPUWritable)
      desc11.Usage = D3D11_USAGE_DYNAMIC;
    else if (data && !(d.isDrawIndirectArgs || d.canHaveUAVs))
      desc11.Usage = D3D11_USAGE_IMMUTABLE;
    else
      desc11.Usage = D3D11_USAGE_DEFAULT;
    
    desc11.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    if (d.canHaveUAVs)
      desc11.BindFlags |= D3D11_BIND_UNORDERED_ACCESS;
   
    desc11.CPUAccessFlags = 0;
    if (d.isCPUWritable)
      desc11.CPUAccessFlags |= D3D11_CPU_ACCESS_WRITE;

    desc11.MiscFlags = 0;
    if (d.isDrawIndirectArgs)
      desc11.MiscFlags |= D3D11_RESOURCE_MISC_DRAWINDIRECT_ARGS;

    if (d.structStride != 0)
      desc11.MiscFlags |= D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;

    desc11.StructureByteStride = (UINT)d.structStride;

    D3D11_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = data;
    initialData.SysMemPitch = 0;
    initialData.SysMemSlicePitch = 0;

    ComPtr<ID3D11Buffer> newBuffer;
    CHECK_ERROR(SUCCEEDED(device->CreateBuffer(&desc11, data ? &initialData : NULL, &newBuffer)), "Creation failed");

    if (d.disableSLISync)
      disableSLIResouceSync(newBuffer.Get());

    //add to our map
    return (BufferHandle)getHandleForBuffer(newBuffer.Get(), &d);
  }

  void IRendererInterfaceD3D11::writeBuffer(BufferHandle b, const void* data, size_t dataSize)
  {
    BufferObjectMap::value_type* handle = (BufferObjectMap::value_type*)b;
    
    if (handle->second.bufferDesc.isCPUWritable)
    {
      //we can map if it it's D3D11_USAGE_DYNAMIC, but not UpdateSubresource
      D3D11_MAPPED_SUBRESOURCE mappedData;
      CHECK_ERROR(SUCCEEDED(context->Map(handle->first.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedData)), "Map failed");
      memcpy(mappedData.pData, data, dataSize);
      context->Unmap(handle->first.Get(), 0);
    }
    else
    {
      context->UpdateSubresource(handle->first.Get(), 0, NULL, data, (UINT)dataSize, 0);
    }
    
  }

  void IRendererInterfaceD3D11::clearBufferUInt(BufferHandle b, uint32_t clearValue)
  {
    BufferObjectMap::value_type* handle = (BufferObjectMap::value_type*)b;
    ID3D11UnorderedAccessView* uav = getUAVForBuffer(handle);
    
    UINT clearValues[4] = { clearValue, clearValue, clearValue, clearValue};
    context->ClearUnorderedAccessViewUint(uav, clearValues);
  }

  void IRendererInterfaceD3D11::copyToBuffer(BufferHandle dest, uint32_t destOffsetBytes, BufferHandle src, uint32_t srcOffsetBytes, size_t dataSizeBytes)
  {
    BufferObjectMap::value_type* handleDest = (BufferObjectMap::value_type*)dest;
    BufferObjectMap::value_type* handleSrc = (BufferObjectMap::value_type*)src;

    //Do a 1D copy
    D3D11_BOX srcBox;
    srcBox.left = (UINT)srcOffsetBytes; 
    srcBox.right = (UINT)(srcOffsetBytes + dataSizeBytes); 
    srcBox.bottom = 1;
    srcBox.top = 0;
    srcBox.front = 0;
    srcBox.back = 1;
    context->CopySubresourceRegion(handleDest->first.Get(), 0, (UINT)destOffsetBytes, 0, 0, handleSrc->first.Get(), 0, &srcBox);
  }

  void IRendererInterfaceD3D11::readBuffer(BufferHandle b, void* data, size_t* dataSize)
  {
    if(!dataSize)
      return;

    size_t bufferSize = *dataSize;
    *dataSize = 0;

    if(!data)
      return;

    BufferObjectMap::value_type* handle = (BufferObjectMap::value_type*)b;

    D3D11_BUFFER_DESC desc;
    handle->first->GetDesc(&desc);
    desc.BindFlags = 0;
    desc.MiscFlags = 0;
    desc.Usage = D3D11_USAGE_STAGING;
    desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;

    ComPtr<ID3D11Buffer> staging;
    if(FAILED(device->CreateBuffer(&desc, NULL, &staging)))
      return;
    
    context->CopyResource(staging.Get(), handle->first.Get());

    D3D11_MAPPED_SUBRESOURCE subresource;
    if(SUCCEEDED(context->Map(staging.Get(), 0, D3D11_MAP_READ, 0, &subresource)))
    {
      size_t bytesCopied = std::min((size_t)desc.ByteWidth, bufferSize);
      memcpy(data, subresource.pData, bytesCopied);
      *dataSize = bytesCopied;

      context->Unmap(staging.Get(), 0);
    }
  }

  void IRendererInterfaceD3D11::destroyBuffer(BufferHandle b)
  {
    BufferObjectMap::value_type* handle = (BufferObjectMap::value_type*)b;
    if (!handle)
      return;

    //smart pointers will clean up for us
    buffers.erase(handle->first);
  }

  ConstantBufferHandle IRendererInterfaceD3D11::createConstantBuffer(const ConstantBufferDesc& d, const void* data)
  {
    //create our staging buffer if we don't have one
    D3D11_BUFFER_DESC desc11;
    desc11.ByteWidth = (UINT)d.byteSize;
    desc11.Usage = D3D11_USAGE_DYNAMIC;
    desc11.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    desc11.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    desc11.MiscFlags = 0;
    desc11.StructureByteStride = 0;

    D3D11_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = data;
    initialData.SysMemPitch = 0;
    initialData.SysMemSlicePitch = 0;

    ID3D11Buffer* constantBuffer = NULL;
    CHECK_ERROR(SUCCEEDED(device->CreateBuffer(&desc11, data ? &initialData : NULL, &constantBuffer)), "Creation of constant buffer failed");

    //we don't need to store any additional stuff so just use the D3D pointer as the handle
    return (ConstantBufferHandle)constantBuffer;
  }

  void IRendererInterfaceD3D11::writeConstantBuffer(ConstantBufferHandle b, const void* data, size_t dataSize)
  {
     ID3D11Buffer* constantBuffer = (ID3D11Buffer*)b;
     
     D3D11_MAPPED_SUBRESOURCE mappedData;
     CHECK_ERROR(SUCCEEDED(context->Map(constantBuffer, 0,D3D11_MAP_WRITE_DISCARD, 0, &mappedData)), "Map failed");
     memcpy(mappedData.pData, data, dataSize);
     context->Unmap(constantBuffer, 0);
  }

  void IRendererInterfaceD3D11::copyToConstantBuffer(ConstantBufferHandle dest, uint32_t destOffsetBytes, BufferHandle src, uint32_t srcOffsetBytes, size_t dataSizeBytes)
  {
     ID3D11Buffer* constantBuffer = (ID3D11Buffer*)dest;
     BufferObjectMap::value_type* handleSrc = (BufferObjectMap::value_type*)src;

     //Do a 1D copy
     D3D11_BOX srcBox;
     srcBox.left = (UINT)srcOffsetBytes; 
     srcBox.right = (UINT)(srcOffsetBytes + dataSizeBytes); 
     srcBox.bottom = 1;
     srcBox.top = 0;
     srcBox.front = 0;
     srcBox.back = 1;
     context->CopySubresourceRegion(constantBuffer, 0, (UINT)destOffsetBytes, 0, 0, handleSrc->first.Get(), 0, &srcBox);
  }

  void IRendererInterfaceD3D11::destroyConstantBuffer(ConstantBufferHandle b)
  {
    ID3D11Buffer* constantBuffer = (ID3D11Buffer*)b;
    if (!constantBuffer)
      return;
    //this should be all it takes
    constantBuffer->Release();
  }


  ShaderHandle IRendererInterfaceD3D11::createShader(const ShaderDesc& d, const void* binary, const size_t binarySize)
  {
    if (d.preCreationCommand)
      d.preCreationCommand->executeAndDispose();

    ID3D11DeviceChild* ret = NULL;
    switch (d.type)
    {
    case ShaderDesc::SHADER_VERTEX:
      {
        ID3D11VertexShader* vs = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreateVertexShader(binary, binarySize, NULL, &vs)), "Creating VS failed");
        ret = vs;
      }
      break;
    case ShaderDesc::SHADER_HULL:
      {
        ID3D11HullShader* hs = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreateHullShader(binary, binarySize, NULL, &hs)), "Creating HS failed");
        ret = hs;
      }
      break;
    case ShaderDesc::SHADER_DOMAIN:
      {
        ID3D11DomainShader* ds = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreateDomainShader(binary, binarySize, NULL, &ds)), "Creating DS failed");
        ret = ds;
      }
      break;
    case ShaderDesc::SHADER_GEOMETRY:
      {
        ID3D11GeometryShader* gs = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreateGeometryShader(binary, binarySize, NULL, &gs)), "Creating GS failed");
        ret = gs;
      }
      break;
    case ShaderDesc::SHADER_PIXEL:
      {
        ID3D11PixelShader* ps = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreatePixelShader(binary, binarySize, NULL, &ps)), "Creating PS failed");
        ret = ps;
      }
      break;
    case ShaderDesc::SHADER_COMPUTE:
      {
        ID3D11ComputeShader* cs = NULL;
        CHECK_ERROR(SUCCEEDED(device->CreateComputeShader(binary, binarySize, NULL, &cs)), "Creating CS failed");
        ret = cs;
      }
      break;
    }

    if (d.postCreationCommand)
      d.postCreationCommand->executeAndDispose();

    return (ShaderHandle)ret;
  }

  ShaderHandle IRendererInterfaceD3D11::createShaderFromAPIInterface(ShaderDesc::SHADER_TYPE shaderType, const void* apiInterface)
  {
    (void)shaderType;
    return (ShaderHandle)apiInterface;
  }

  void IRendererInterfaceD3D11::destroyShader(ShaderHandle s)
  {
    ID3D11DeviceChild* shader = (ID3D11DeviceChild*)s;
    if (!shader)
      return;

    shader->Release();
  }

  //These are only in very new DXSDKs
#ifndef D3D11_FILTER_REDUCTION_TYPE_COMPARISON
#define D3D11_FILTER_REDUCTION_TYPE_COMPARISON 1
#endif

#ifndef D3D11_FILTER_REDUCTION_TYPE_STANDARD
#define D3D11_FILTER_REDUCTION_TYPE_STANDARD 0
#endif

  SamplerHandle IRendererInterfaceD3D11::createSampler(const SamplerDesc& d)
  {

    //convert the sampler dessc
    D3D11_SAMPLER_DESC desc11;
    if (d.anisotropy > 1.0f)
    {
      desc11.Filter = D3D11_ENCODE_ANISOTROPIC_FILTER(d.shadowCompare ? D3D11_FILTER_REDUCTION_TYPE_COMPARISON : D3D11_FILTER_REDUCTION_TYPE_STANDARD);
    }
    else
    {
      desc11.Filter = D3D11_ENCODE_BASIC_FILTER(d.minFilter ? D3D11_FILTER_TYPE_LINEAR : D3D11_FILTER_TYPE_POINT, d.magFilter ? D3D11_FILTER_TYPE_LINEAR : D3D11_FILTER_TYPE_POINT, d.mipFilter ? D3D11_FILTER_TYPE_LINEAR : D3D11_FILTER_TYPE_POINT, d.shadowCompare ? D3D11_FILTER_REDUCTION_TYPE_COMPARISON : D3D11_FILTER_REDUCTION_TYPE_STANDARD);
    }
    D3D11_TEXTURE_ADDRESS_MODE* dest[] = { &desc11.AddressU, &desc11.AddressV, &desc11.AddressW };
    for (int i = 0; i < 3; i++)
    {
      switch(d.wrapMode[i])
      {
      case SamplerDesc::WRAP_MODE_BORDER:
        *dest[i] = D3D11_TEXTURE_ADDRESS_BORDER;
        break;
      case SamplerDesc::WRAP_MODE_CLAMP:
        *dest[i] = D3D11_TEXTURE_ADDRESS_CLAMP;
        break;
      case SamplerDesc::WRAP_MODE_WRAP:
        *dest[i] = D3D11_TEXTURE_ADDRESS_WRAP;
        break;
      }
    }

    desc11.MipLODBias = d.mipBias;
    desc11.MaxAnisotropy = std::max((UINT)d.anisotropy, 1U);
    desc11.ComparisonFunc = D3D11_COMPARISON_LESS;
    desc11.BorderColor[0] = d.borderColor[0];
    desc11.BorderColor[1] = d.borderColor[1];
    desc11.BorderColor[2] = d.borderColor[2];
    desc11.BorderColor[3] = d.borderColor[3];
    desc11.MinLOD = 0;
    desc11.MaxLOD = D3D11_FLOAT32_MAX;

    ID3D11SamplerState* sState = NULL;
    CHECK_ERROR(SUCCEEDED(device->CreateSamplerState(&desc11, &sState)), "Creating sampler state failed");

    return (SamplerHandle)sState;
  }

  void IRendererInterfaceD3D11::destroySampler(SamplerHandle s)
  {
    ID3D11SamplerState* sState = (ID3D11SamplerState*)s;
    if (!sState)
      return;
    sState->Release();
  }

  void* IRendererInterfaceD3D11::getAPISpecificInterface(APISpecificInterface::Enum interfaceType)
  {
    if (interfaceType == APISpecificInterface::D3D11DEVICECONTEXT)
    {
      //we only support this interface type
      ID3D11DeviceContext* d3d11Context = context.Get();
      return d3d11Context;
    }
    else  if (interfaceType == APISpecificInterface::D3D11DEVICE)
    {
      //we only support this interface type
      ID3D11Device* d3d11Device = device.Get();
      return d3d11Device;
    }
    return NULL;
  }

  void IRendererInterfaceD3D11::drawNonIndexedVertices(const DrawCallState& state, PrimitiveType::Enum primType, uint32_t vertexCount, uint32_t instanceCount)
  {
    clearState();
    applyState(state);
    context->IASetPrimitiveTopology(getPrimType(primType));

    context->DrawInstanced(vertexCount, instanceCount, 0, 0);

    clearState();
  }

  void IRendererInterfaceD3D11::drawNonIndexedVerticesIndirect(const DrawCallState& state, PrimitiveType::Enum primType, BufferHandle indirectParams, uint32_t offsetBytes)
  {
    clearState();
    applyState(state);
    context->IASetPrimitiveTopology(getPrimType(primType));
    
    BufferObjectMap::value_type* handle = (BufferObjectMap::value_type*)indirectParams;
    context->DrawInstancedIndirect(handle->first.Get(), offsetBytes);

    clearState();
  }

  void IRendererInterfaceD3D11::dispatchCompute(const DispatchState& state, const Vector3u& groupCount)
  {
    clearState();
    applyState(state);

    context->Dispatch((UINT)groupCount.x, (UINT)groupCount.y, (UINT)groupCount.z);

    clearState();
  }

  void IRendererInterfaceD3D11::dispatchComputeIndirect(const DispatchState& state, BufferHandle indirectParams, uint32_t offsetBytes)
  {
    clearState();
    applyState(state);

    BufferObjectMap::value_type* handleArgs = (BufferObjectMap::value_type*)indirectParams;
    context->DispatchIndirect(handleArgs->first.Get(), (UINT)offsetBytes);

    clearState();
  }

  IRendererInterfaceD3D11::TextureObjectMap::value_type* IRendererInterfaceD3D11::getHandleForTexture(ID3D11Resource* resource, const TextureDesc* textureDesc)
  {
    if (!resource) //if it's null, we want a null handle
      return NULL;

    TextureObjectMap::iterator it = textures.find(resource);
    if (it == textures.end())
    {
      it = textures.insert(TextureObjectMap::value_type(resource, TextureViewSet())).first; //we haven't seen this one before

      //use our provided one or make one from the D3D data
      it->second.textureDesc = textureDesc ? *textureDesc : getTextureDescFromD3D11Resource(resource);
      
      //Resize these withe empty views to the right sizes for simplicity later
      it->second.unorderedAccessViewsPerMip.resize(it->second.textureDesc.mipLevels);
    }

    TextureObjectMap::value_type& mapValue = *it;
    return &mapValue;
  }

  void IRendererInterfaceD3D11::getClearViewForTexture(TextureObjectMap::value_type* resource, uint32_t index, bool asUINT, ID3D11UnorderedAccessView*& outUAV, ID3D11RenderTargetView*& outRTV, ID3D11DepthStencilView*& outDSV)
  {
    outUAV = NULL;
    outRTV = NULL;
    outDSV = NULL;

    const TextureDesc& textureDesc = resource->second.textureDesc;
    //Try UAVs first since they are more flexible
    if (textureDesc.isUAV)
    {
      DXGI_FORMAT format;

      if(asUINT)
        format = DXGI_FORMAT_R32_UINT;
      else
        if(textureDesc.format == TextureDesc::FORMAT_RGBA16F)
          format = DXGI_FORMAT_R16G16B16A16_FLOAT;
        else
          format = DXGI_FORMAT_R32_FLOAT;

      //we have UAVs;
      if (index < textureDesc.mipLevels)
        outUAV = getUAVForTexture(resource, format, index); //return or create a UAV or return null if we are out of mips
    }
    else if (textureDesc.isRenderTarget)
    {
      //if we are still within the volume or array
      if ((index == 0 && !textureDesc.isArray) || index < textureDesc.dimensions.z)
      {
        if (textureDesc.format == TextureDesc::FORMAT_D16 || textureDesc.format == TextureDesc::FORMAT_D24S8 || textureDesc.format == TextureDesc::FORMAT_D32)
          outDSV = getDSVForTexture(resource, index); //return or create a RT
        else
          outRTV = getRTVForTexture(resource, index); //return or create a RT
      }
    }
    else
    {
      CHECK_ERROR(0, "This resource cannot be cleared");
    }
  }

  ID3D11ShaderResourceView* IRendererInterfaceD3D11::getSRVForTexture(TextureObjectMap::value_type* resource, DXGI_FORMAT format, uint32_t mipLevel)
  {
    ComPtr<ID3D11ShaderResourceView>& srvPtr = resource->second.shaderResourceViews[std::make_pair(format, mipLevel)];
    if (srvPtr == NULL)
    {
      //we haven't seen this one before
      const TextureDesc& textureDesc = resource->second.textureDesc;
      D3D11_SHADER_RESOURCE_VIEW_DESC desc11;
      desc11.Format = format;
      if (textureDesc.isCubeMap)
      {
        if(textureDesc.dimensions.z > 6)
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBEARRAY;
        else
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE;
        desc11.Texture2DArray.ArraySize = (UINT)textureDesc.dimensions.z / 6;
        desc11.Texture2DArray.FirstArraySlice = 0;

        if(mipLevel == ~0u)
        {
          desc11.Texture2DArray.MipLevels = (UINT)textureDesc.mipLevels;
          desc11.Texture2DArray.MostDetailedMip = 0;
        }
        else
        {
          desc11.Texture2DArray.MipLevels = 1;
          desc11.Texture2DArray.MostDetailedMip = mipLevel;
        }
      }
      else if (textureDesc.isArray)
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2DMSARRAY;
          desc11.Texture2DMSArray.ArraySize = (UINT)textureDesc.dimensions.z;
          desc11.Texture2DMSArray.FirstArraySlice = 0;
        }
        else
        {
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2DARRAY;
          desc11.Texture2DArray.ArraySize = (UINT)textureDesc.dimensions.z;
          desc11.Texture2DArray.FirstArraySlice = 0;

          if(mipLevel == ~0u)
          {
            desc11.Texture2DArray.MipLevels = (UINT)textureDesc.mipLevels;
            desc11.Texture2DArray.MostDetailedMip = 0;
          }
          else
          {
            desc11.Texture2DArray.MipLevels = 1;
            desc11.Texture2DArray.MostDetailedMip = mipLevel;
          }
        }
      }
      else if (textureDesc.dimensions.z > 0)
      {
        desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE3D;

        if(mipLevel == ~0u)
        {
          desc11.Texture3D.MipLevels = (UINT)textureDesc.mipLevels;
          desc11.Texture3D.MostDetailedMip = 0;
        }
        else
        {
          desc11.Texture3D.MipLevels = 1;
          desc11.Texture3D.MostDetailedMip = mipLevel;
        }
      }
      else
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2DMS;
        }
        else
        {
          desc11.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;

          if(mipLevel == ~0u)
          {
            desc11.Texture2D.MipLevels = (UINT)textureDesc.mipLevels;
            desc11.Texture2D.MostDetailedMip = 0;
          }
          else
          {
            desc11.Texture2D.MipLevels = 1;
            desc11.Texture2D.MostDetailedMip = mipLevel;
          }
        }
      }
      CHECK_ERROR(SUCCEEDED(device->CreateShaderResourceView(resource->first.Get(), &desc11, &srvPtr)), "Creating the view failed");
    }
    return srvPtr.Get();
  }

  ID3D11ShaderResourceView* IRendererInterfaceD3D11::getSRVForTexture(TextureHandle handle, uint32_t mipLevel)
  {
    TextureObjectMap::value_type* resource = (TextureObjectMap::value_type*)handle;
    UINT dontCare;
    return getSRVForTexture(resource, getTypedTextureFormat(resource->second.textureDesc.format, dontCare, true), mipLevel);
  }

  ID3D11RenderTargetView* IRendererInterfaceD3D11::getRTVForTexture(TextureObjectMap::value_type* resource, uint32_t arrayItem, uint32_t mipLevel)
  {
    ComPtr<ID3D11RenderTargetView>& rtvPtr = resource->second.renderTargetViews[std::make_pair(arrayItem, mipLevel)];
    if (rtvPtr == NULL)
    {
      //we haven't seen this one before
      const TextureDesc& textureDesc = resource->second.textureDesc;
      D3D11_RENDER_TARGET_VIEW_DESC desc11;
      UINT dontCare;
      desc11.Format = getTypedTextureFormat(textureDesc.format, dontCare, false);
      if (textureDesc.isArray)
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DMSARRAY;
          desc11.Texture2DMSArray.ArraySize = 1;
          desc11.Texture2DMSArray.FirstArraySlice = (UINT)arrayItem;
        }
        else
        {
          desc11.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY;
          desc11.Texture2DArray.ArraySize = 1;
          desc11.Texture2DArray.FirstArraySlice = (UINT)arrayItem;
          desc11.Texture2DArray.MipSlice = mipLevel;
        }
      }
      else if (textureDesc.dimensions.z > 0)
      {
        desc11.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE3D;
        desc11.Texture3D.FirstWSlice = (UINT)arrayItem;
        desc11.Texture3D.WSize = 1;
        desc11.Texture3D.MipSlice = mipLevel;
      }
      else
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DMS;
        }
        else
        {
          desc11.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
          desc11.Texture2D.MipSlice = mipLevel;
        }
      }
      CHECK_ERROR(SUCCEEDED(device->CreateRenderTargetView(resource->first.Get(), &desc11, &rtvPtr)), "Creating the view failed");
    }
    return rtvPtr.Get();
  }

  ID3D11DepthStencilView* IRendererInterfaceD3D11::getDSVForTexture(TextureObjectMap::value_type* resource, uint32_t arrayItem, uint32_t mipLevel)
  {
    ComPtr<ID3D11DepthStencilView>& dsvPtr = resource->second.depthStencilViews[std::make_pair(arrayItem, mipLevel)];
    if (dsvPtr == NULL)
    {
      //we haven't seen this one before
      const TextureDesc& textureDesc = resource->second.textureDesc;
      D3D11_DEPTH_STENCIL_VIEW_DESC desc11;
      UINT dontCare;
      desc11.Format = getTypedTextureFormat(textureDesc.format, dontCare, false);
      desc11.Flags = 0;
      if (textureDesc.isArray)
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMSARRAY;
          desc11.Texture2DMSArray.ArraySize = 1;
          desc11.Texture2DMSArray.FirstArraySlice = (UINT)arrayItem;
        }
        else
        {
          desc11.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DARRAY;
          desc11.Texture2DArray.ArraySize = 1;
          desc11.Texture2DArray.FirstArraySlice = (UINT)arrayItem;
          desc11.Texture2DArray.MipSlice = mipLevel;
        }
      }
      else if (textureDesc.dimensions.z > 0)
      {
        CHECK_ERROR(0, "No 3D depth textures");
      }
      else
      {
        if (textureDesc.sampleCount > 1)
        {
          desc11.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
        }
        else
        {
          desc11.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
          desc11.Texture2D.MipSlice = mipLevel;
        }
      }
      CHECK_ERROR(SUCCEEDED(device->CreateDepthStencilView(resource->first.Get(), &desc11, &dsvPtr)), "Creating the view failed");
    }
    return dsvPtr.Get();
  }

  ID3D11UnorderedAccessView* IRendererInterfaceD3D11::getUAVForTexture(TextureObjectMap::value_type* resource, DXGI_FORMAT format, uint32_t mipLevel /*= 0*/)
  {
    ComPtr<ID3D11UnorderedAccessView>& uavPtr = resource->second.unorderedAccessViewsPerMip[mipLevel][format];
    if (uavPtr == NULL)
    {
      //we haven't seen this one before
      const TextureDesc& textureDesc = resource->second.textureDesc;

      CHECK_ERROR(textureDesc.sampleCount <= 1, "You cannot access a multisample UAV");

      D3D11_UNORDERED_ACCESS_VIEW_DESC desc11;
      desc11.Format = format;
      if (textureDesc.isArray)
      {
        desc11.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2DARRAY;
        desc11.Texture2DArray.ArraySize = (UINT)textureDesc.dimensions.z;
        desc11.Texture2DArray.FirstArraySlice = 0;
        desc11.Texture2DArray.MipSlice = (UINT)mipLevel;
      }
      else if (textureDesc.dimensions.z > 0)
      {
        desc11.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE3D;
        desc11.Texture3D.FirstWSlice = 0;
        desc11.Texture3D.WSize = (UINT)textureDesc.dimensions.z;
        desc11.Texture3D.MipSlice = (UINT)mipLevel;
      }
      else
      {
        desc11.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2D;
        desc11.Texture2D.MipSlice = (UINT)mipLevel;
    }
      CHECK_ERROR(SUCCEEDED(device->CreateUnorderedAccessView(resource->first.Get(), &desc11, &uavPtr)), "Creating the view failed");
    }
    return uavPtr.Get();
  }

  void IRendererInterfaceD3D11::applyState(const DrawCallState& state)
  {
    ID3D11RenderTargetView* renderTargetViews[D3D11_PS_OUTPUT_REGISTER_COUNT] = {0};
    UINT rtvCount = 0;
    ID3D11DepthStencilView* depthView = NULL;

    D3D11_VIEWPORT viewports[D3D11_VIEWPORT_AND_SCISSORRECT_MAX_INDEX] = {0};
    D3D11_RECT scissorRects[D3D11_VIEWPORT_AND_SCISSORRECT_MAX_INDEX] = {0};

    const RenderState& renderState = state.renderState;
    FLOAT clearColor[4] = { renderState.clearColor.x, renderState.clearColor.y, renderState.clearColor.z, renderState.clearColor.w };
    //Setup the targets
    for (uint32_t rt = 0; rt < renderState.targetCount; rt++)
    {
      if (renderState.targets[rt] != NULL)
      {
        renderTargetViews[rt] = getRTVForTexture((TextureObjectMap::value_type*)renderState.targets[rt], state.renderState.targetIndicies[rt], state.renderState.targetMipSlices[rt]);
        rtvCount = std::max(rtvCount, (UINT)rt + 1);
        //clear stuff if required
        if (renderState.clearColorTarget)
          context->ClearRenderTargetView(renderTargetViews[rt], clearColor);
      }
      //copy viewport
      viewports[rt].TopLeftX = renderState.viewports[rt].lower.x;
      viewports[rt].TopLeftY = renderState.viewports[rt].lower.y;
      viewports[rt].Width = renderState.viewports[rt].upper.x - renderState.viewports[rt].lower.x;
      viewports[rt].Height = renderState.viewports[rt].upper.y - renderState.viewports[rt].lower.y;
      viewports[rt].MinDepth = renderState.viewports[rt].lower.z;
      viewports[rt].MaxDepth = renderState.viewports[rt].upper.z;

      scissorRects[rt].left = (LONG)renderState.scissorRects[rt].lower.x;
      scissorRects[rt].top = (LONG)renderState.scissorRects[rt].lower.y;
      scissorRects[rt].right = (LONG)renderState.scissorRects[rt].upper.x;
      scissorRects[rt].bottom = (LONG)renderState.scissorRects[rt].upper.y;
    }
    
    if (state.renderState.depthTarget)
      depthView = getDSVForTexture((TextureObjectMap::value_type*)state.renderState.depthTarget, state.renderState.depthIndex, state.renderState.depthMipSlice);

    //clear stuff if required
    if (depthView && (renderState.clearDepthTarget || renderState.clearStencilTarget))
    {
      UINT clearFlags = 0;
      if (renderState.clearDepthTarget)
        clearFlags |= D3D11_CLEAR_DEPTH;
      if (renderState.clearStencilTarget)
        clearFlags |= D3D11_CLEAR_STENCIL;

      context->ClearDepthStencilView(depthView, clearFlags, renderState.clearDepth, (UINT8)renderState.clearStencil);
    }

    //Apply them
    context->RSSetViewports((UINT)renderState.targetCount, viewports);
    context->RSSetScissorRects((UINT)renderState.targetCount, scissorRects);

    const StateSet& d3d11State = getStateSet(renderState);
    //set the states
    context->RSSetState(d3d11State.rasterState.Get());
    FLOAT blendFactor[4] = { renderState.blendState.blendFactor.x, renderState.blendState.blendFactor.y, renderState.blendState.blendFactor.z, renderState.blendState.blendFactor.w};
    context->OMSetBlendState(d3d11State.blendState.Get(), blendFactor, D3D11_DEFAULT_SAMPLE_MASK);
    context->OMSetDepthStencilState(d3d11State.depthState.Get(), (UINT)renderState.depthStencilState.stencilRefValue);

    //Bind resources
    for (uint32_t stage = 0; stage < DrawCallState::SHADERS_COUNT; stage++)
    {
      //Apply the shader. We cast to ID3D11DeviceChild first since that's what the handle is cast to before it was given to VXGI
      ID3D11DeviceChild* baseShader = (ID3D11DeviceChild*)state.shaders[stage];
      if (baseShader == NULL)
        continue; //nothing bound here

      ID3D11ShaderResourceView* shaderResourceViews[D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT] = {0};
      UINT minSRV = D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT, maxSRV = 0;

      ID3D11UnorderedAccessView* unorderedAccessViews[D3D11_PS_CS_UAV_REGISTER_COUNT] = {0};
      UINT minUAV = D3D11_PS_CS_UAV_REGISTER_COUNT, maxUAV = 0;
      UINT uavCountersUnused[D3D11_PS_CS_UAV_REGISTER_COUNT] = {D3D11_KEEP_UNORDERED_ACCESS_VIEWS};

      ID3D11Buffer* constantBuffers[D3D11_COMMONSHADER_CONSTANT_BUFFER_REGISTER_COUNT] = {0};
      UINT minCB = D3D11_COMMONSHADER_CONSTANT_BUFFER_REGISTER_COUNT, maxCB = 0;

      ID3D11SamplerState* samplers[D3D11_COMMONSHADER_SAMPLER_REGISTER_COUNT] = {0};
      UINT minSS = D3D11_COMMONSHADER_SAMPLER_REGISTER_COUNT, maxSS = 0;

      //Bind textures
      for (uint32_t i = 0; i < state.textureBindingCount[stage]; i++)
      {
        DXGI_FORMAT textureFormat = DXGI_FORMAT_UNKNOWN;
        UINT dontCareSize;
        UINT slot = (UINT)state.textures[stage][i].slot;      
        TextureObjectMap::value_type* resource = (TextureObjectMap::value_type*)state.textures[stage][i].value;
        switch(state.textures[stage][i].format)
        {
        case Binding<TextureHandle>::FORMAT_R32U:  textureFormat = DXGI_FORMAT_R32_UINT; break;
        case Binding<TextureHandle>::FORMAT_RGBA8_UNORM:  textureFormat = DXGI_FORMAT_R8G8B8A8_UNORM; break;
		case Binding<TextureHandle>::FORMAT_BGRA8_UNORM:  textureFormat = DXGI_FORMAT_B8G8R8A8_UNORM; break;
		case Binding<TextureHandle>::FORMAT_RGBA16F:  textureFormat = DXGI_FORMAT_R16G16B16A16_FLOAT; break;
        case Binding<TextureHandle>::FORMAT_X24G8_UINT:  textureFormat = DXGI_FORMAT_X24_TYPELESS_G8_UINT; break;
        case Binding<TextureHandle>::FORMAT_UNSET:  textureFormat = getTypedTextureFormat(resource->second.textureDesc.format, dontCareSize, true); break;
        default:
          CHECK_ERROR(0, "Unknown format");
        }

        //choose a SRV or UAV
        if (state.textures[stage][i].isWritable)
        {
          CHECK_ERROR(stage == DrawCallState::SHADER_PIXEL, "UAVs only supported in pixel shaders");
          unorderedAccessViews[slot] = getUAVForTexture(resource, textureFormat, state.textures[stage][i].mipLevel);
          minUAV = std::min(slot, minUAV);
          maxUAV = std::max(slot, maxUAV);
        }
        else
        {
          shaderResourceViews[slot] = getSRVForTexture(resource, textureFormat, state.textures[stage][i].mipLevel);
          minSRV = std::min(slot, minSRV);
          maxSRV = std::max(slot, maxSRV);
        }
      }

      //Bind samplers
      for (uint32_t i = 0; i < state.textureSamplerBindingCount[stage]; i++)
      {
        UINT slot = (UINT)state.textureSamplers[stage][i].slot;     
        ID3D11SamplerState* sampler = (ID3D11SamplerState*)state.textureSamplers[stage][i].value;

        samplers[slot] = sampler;
        minSS = std::min(slot, minSS);
        maxSS = std::max(slot, maxSS);
      }

      //Bind buffers
      for (uint32_t i = 0; i < state.bufferBindingCount[stage]; i++)
      {
        UINT slot = (UINT)state.buffers[stage][i].slot;     
        BufferObjectMap::value_type* resource = (BufferObjectMap::value_type*)state.buffers[stage][i].value;
        //choose a SRV or UAV
        if (state.buffers[stage][i].isWritable)
        {
          CHECK_ERROR(stage == DrawCallState::SHADER_PIXEL, "UAVs only supported in pixel shaders");
          unorderedAccessViews[slot] = getUAVForBuffer(resource);
          minUAV = std::min(slot, minUAV);
          maxUAV = std::max(slot, maxUAV);
        }
        else
        {
          shaderResourceViews[slot] = getSRVForBuffer(resource);
          minSRV = std::min(slot, minSRV);
          maxSRV = std::max(slot, maxSRV);
        }
      }

      //bind Constant buffers
      for (uint32_t i = 0; i < state.constantBufferBindingCount[stage]; i++)
      {
        UINT slot = (UINT)state.constantBuffers[stage][i].slot;     
        ID3D11Buffer* cbuffer = (ID3D11Buffer*)state.constantBuffers[stage][i].value;

        constantBuffers[slot] = cbuffer;
        minCB = std::min(slot, minCB);
        maxCB = std::max(slot, maxCB);
      }

      switch(stage)
      {
        case DrawCallState::SHADER_VERTEX:
        {
          ComPtr<ID3D11VertexShader> shader;
          baseShader->QueryInterface<ID3D11VertexShader>(&shader);
          CHECK_ERROR(shader != NULL, "This is not the right shader type");

          //apply the shader
          context->VSSetShader(shader.Get(), NULL, 0);


          //Apply them to the context
          if (maxCB >= minCB)
            context->VSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

          if (maxSRV >= minSRV)
            context->VSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

          if (maxSS >= minSS)
            context->VSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);
          
          break;
        }
        case DrawCallState::SHADER_GEOMETRY:
        {
          ComPtr<ID3D11GeometryShader> shader;
          baseShader->QueryInterface<ID3D11GeometryShader>(&shader);
          CHECK_ERROR(shader != NULL, "This is not the right shader type");

          //apply the shader
          context->GSSetShader(shader.Get(), NULL, 0);


          //Apply them to the context
          if (maxCB >= minCB)
            context->GSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

          if (maxSRV >= minSRV)
            context->GSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

          if (maxSS >= minSS)
            context->GSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);

          break;
        }
        case DrawCallState::SHADER_HULL:
        {
          ComPtr<ID3D11HullShader> shader;
          baseShader->QueryInterface<ID3D11HullShader>(&shader);
          CHECK_ERROR(shader != NULL, "This is not the right shader type");

          //apply the shader
          context->HSSetShader(shader.Get(), NULL, 0);


          //Apply them to the context
          if (maxCB >= minCB)
            context->HSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

          if (maxSRV >= minSRV)
            context->HSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

          if (maxSS >= minSS)
            context->HSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);

          break;
        }
        case DrawCallState::SHADER_DOMAIN:
        {
          ComPtr<ID3D11DomainShader> shader;
          baseShader->QueryInterface<ID3D11DomainShader>(&shader);
          CHECK_ERROR(shader != NULL, "This is not the right shader type");

          //apply the shader
          context->DSSetShader(shader.Get(), NULL, 0);


          //Apply them to the context
          if (maxCB >= minCB)
            context->DSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

          if (maxSRV >= minSRV)
            context->DSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

          if (maxSS >= minSS)
            context->DSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);

          break;
        }
        case DrawCallState::SHADER_PIXEL:
        {
          ComPtr<ID3D11PixelShader> shader;
          baseShader->QueryInterface<ID3D11PixelShader>(&shader);
          CHECK_ERROR(shader != NULL, "This is not the right shader type");

          //apply the shader
          context->PSSetShader(shader.Get(), NULL, 0);


          //Apply them to the context
          if (maxCB >= minCB)
            context->PSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

          if (maxSRV >= minSRV)
            context->PSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

          if (maxSS >= minSS)
            context->PSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);

          if (maxUAV >= minUAV)
          {
            context->OMSetRenderTargetsAndUnorderedAccessViews(rtvCount, renderTargetViews, depthView, minUAV, maxUAV - minUAV + 1, unorderedAccessViews + minUAV, uavCountersUnused);
          }
          else
          {
            context->OMSetRenderTargets(rtvCount, renderTargetViews, depthView);
          }

          break;
        }
      }
     
    }
  }

  void IRendererInterfaceD3D11::applyState(const DispatchState& state)
  {
    //Apply the shader. We cast to ID3D11DeviceChild first since that's what the handle is cast to before it was given to VXGI
    ID3D11DeviceChild* baseShader = (ID3D11DeviceChild*)state.shader;
    ComPtr<ID3D11ComputeShader> computeShader;
    baseShader->QueryInterface<ID3D11ComputeShader>(&computeShader);
    CHECK_ERROR(computeShader != NULL, "This is not a compute shader");

    //apply the shader
    context->CSSetShader(computeShader.Get(), NULL, 0);

    ID3D11ShaderResourceView* shaderResourceViews[D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT] = {0};
    UINT minSRV = D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT, maxSRV = 0;

    ID3D11UnorderedAccessView* unorderedAccessViews[D3D11_PS_CS_UAV_REGISTER_COUNT] = {0};
    UINT minUAV = D3D11_PS_CS_UAV_REGISTER_COUNT, maxUAV = 0;
    UINT uavCountersUnused[D3D11_PS_CS_UAV_REGISTER_COUNT] = {D3D11_KEEP_UNORDERED_ACCESS_VIEWS};

    ID3D11Buffer* constantBuffers[D3D11_COMMONSHADER_CONSTANT_BUFFER_REGISTER_COUNT] = {0};
    UINT minCB = D3D11_COMMONSHADER_CONSTANT_BUFFER_REGISTER_COUNT, maxCB = 0;

    ID3D11SamplerState* samplers[D3D11_COMMONSHADER_SAMPLER_REGISTER_COUNT] = {0};
    UINT minSS = D3D11_COMMONSHADER_SAMPLER_REGISTER_COUNT, maxSS = 0;

    //Bind textures
    for (uint32_t i = 0; i < state.textureBindingCount; i++)
    {
      DXGI_FORMAT textureFormat = DXGI_FORMAT_UNKNOWN;
      UINT dontCareSize;
      UINT slot = (UINT)state.textures[i].slot;      
      TextureObjectMap::value_type* resource = (TextureObjectMap::value_type*)state.textures[i].value;
      switch(state.textures[i].format)
      {
        case Binding<TextureHandle>::FORMAT_R32U:  textureFormat = DXGI_FORMAT_R32_UINT; break;
        case Binding<TextureHandle>::FORMAT_RGBA8_UNORM:  textureFormat = DXGI_FORMAT_R8G8B8A8_UNORM; break;
        case Binding<TextureHandle>::FORMAT_BGRA8_UNORM:  textureFormat = DXGI_FORMAT_B8G8R8A8_UNORM; break;
        case Binding<TextureHandle>::FORMAT_RGBA16F:  textureFormat = DXGI_FORMAT_R16G16B16A16_FLOAT; break;
        case Binding<TextureHandle>::FORMAT_X24G8_UINT:  textureFormat = DXGI_FORMAT_X24_TYPELESS_G8_UINT; break;
        case Binding<TextureHandle>::FORMAT_UNSET:  textureFormat = getTypedTextureFormat(resource->second.textureDesc.format, dontCareSize, true); break;
        default:
          CHECK_ERROR(0, "Unknown format");
      }

      //choose a SRV or UAV
      if (state.textures[i].isWritable)
      {
        unorderedAccessViews[slot] = getUAVForTexture(resource, textureFormat, state.textures[i].mipLevel);
        minUAV = std::min(slot, minUAV);
        maxUAV = std::max(slot, maxUAV);
      }
      else
      {
        shaderResourceViews[slot] = getSRVForTexture(resource, textureFormat, state.textures[i].mipLevel);
        minSRV = std::min(slot, minSRV);
        maxSRV = std::max(slot, maxSRV);
      }
    }

    //Bind samplers
    for (uint32_t i = 0; i < state.textureSamplerBindingCount; i++)
    {
      UINT slot = (UINT)state.textureSamplers[i].slot;     
      ID3D11SamplerState* sampler = (ID3D11SamplerState*)state.textureSamplers[i].value;
      
      samplers[slot] = sampler;
      minSS = std::min(slot, minSS);
      maxSS = std::max(slot, maxSS);
    }

    //Bind buffers
    for (uint32_t i = 0; i < state.bufferBindingCount; i++)
    {
      UINT slot = (UINT)state.buffers[i].slot;     
      BufferObjectMap::value_type* resource = (BufferObjectMap::value_type*)state.buffers[i].value;
      //choose a SRV or UAV
      if (state.buffers[i].isWritable)
      {
        unorderedAccessViews[slot] = getUAVForBuffer(resource);
        minUAV = std::min(slot, minUAV);
        maxUAV = std::max(slot, maxUAV);
      }
      else
      {
        shaderResourceViews[slot] = getSRVForBuffer(resource);
        minSRV = std::min(slot, minSRV);
        maxSRV = std::max(slot, maxSRV);
      }
    }

    //bind Constant buffers
    for (uint32_t i = 0; i < state.constantBufferBindingCount; i++)
    {
      UINT slot = (UINT)state.constantBuffers[i].slot;     
      ID3D11Buffer* cbuffer = (ID3D11Buffer*)state.constantBuffers[i].value;

      constantBuffers[slot] = cbuffer;
      minCB = std::min(slot, minCB);
      maxCB = std::max(slot, maxCB);
    }

    //Apply them to the context
    if (maxCB >= minCB)
      context->CSSetConstantBuffers(minCB, maxCB - minCB + 1, constantBuffers + minCB);

    if (maxSRV >= minSRV)
      context->CSSetShaderResources(minSRV, maxSRV - minSRV + 1, shaderResourceViews + minSRV);

    if (maxSS >= minSS)
      context->CSSetSamplers(minSS, maxSS - minSS + 1, samplers + minSS);

    if (maxUAV >= minUAV)
      context->CSSetUnorderedAccessViews(minUAV, maxUAV - minUAV + 1, unorderedAccessViews + minUAV, uavCountersUnused);
  }

  void IRendererInterfaceD3D11::clearState()
  {
      //
      // Unbind shaders
      //
      context->VSSetShader(NULL, NULL, 0);
      context->GSSetShader(NULL, NULL, 0);
      context->PSSetShader(NULL, NULL, 0);
      context->CSSetShader(NULL, NULL, 0);

      //
      // Unbind resources
      //
      ID3D11RenderTargetView *pRTVs[8] = { 0 };
      context->OMSetRenderTargets(ARRAYSIZE(pRTVs), pRTVs, NULL);

      ID3D11ShaderResourceView* pSRVs[D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT] = { 0 };
      context->VSSetShaderResources(0, ARRAYSIZE(pSRVs), pSRVs);
      context->GSSetShaderResources(0, ARRAYSIZE(pSRVs), pSRVs);
      context->PSSetShaderResources(0, ARRAYSIZE(pSRVs), pSRVs);
      context->CSSetShaderResources(0, ARRAYSIZE(pSRVs), pSRVs);

      ID3D11UnorderedAccessView* pUAVs[D3D11_PS_CS_UAV_REGISTER_COUNT] = { 0 };
      UINT pUAVInitialCounts[D3D11_PS_CS_UAV_REGISTER_COUNT] = { 0 };
      context->CSSetUnorderedAccessViews(0, ARRAYSIZE(pUAVs), pUAVs, pUAVInitialCounts);

      context->RSSetState(NULL);
  }

  //This dedudces a TextureDesc from a D3D11 texture. This is called if VXGI wants information about a texture that it did not create itself.
  TextureDesc IRendererInterfaceD3D11::getTextureDescFromD3D11Resource(ID3D11Resource* resource)
  {

    TextureDesc returnValue;
    returnValue.debugName = NULL;

    D3D11_USAGE usage = D3D11_USAGE_DEFAULT;
    DXGI_FORMAT format = DXGI_FORMAT_UNKNOWN;

    //Texture2D?
    ComPtr<ID3D11Texture2D> texture2D;
    resource->QueryInterface<ID3D11Texture2D>(&texture2D);
    if (texture2D != NULL)
    {
      D3D11_TEXTURE2D_DESC desc11;
      texture2D->GetDesc(&desc11);

      usage = desc11.Usage;
      format = desc11.Format;
      returnValue.isCPUWritable = (desc11.CPUAccessFlags & D3D11_CPU_ACCESS_WRITE) != 0;
      returnValue.isRenderTarget = (desc11.BindFlags & (D3D11_BIND_RENDER_TARGET | D3D11_BIND_DEPTH_STENCIL)) != 0;
      returnValue.isUAV = (desc11.BindFlags & D3D11_BIND_UNORDERED_ACCESS) != 0;
      returnValue.mipLevels = (uint32_t)desc11.MipLevels;
      returnValue.sampleCount = (uint32_t)desc11.SampleDesc.Count;
      returnValue.sampleQuality = (uint32_t)desc11.SampleDesc.Quality;

      returnValue.isArray = desc11.ArraySize > 1;
      returnValue.isCubeMap = (desc11.MiscFlags & D3D11_RESOURCE_MISC_TEXTURECUBE) != 0;
      //settings .z == 1, would imply a 3d texture unless isArray is set
      returnValue.dimensions = Vector3u((uint32_t)desc11.Width, (uint32_t)desc11.Height, (uint32_t)(returnValue.isArray ? desc11.ArraySize : 0));

    }
    else
    {
      //Texture3D?
      ComPtr<ID3D11Texture3D> texture3D;
      resource->QueryInterface<ID3D11Texture3D>(&texture3D);
      if (texture3D != NULL)
      {
        D3D11_TEXTURE3D_DESC desc11;
        texture3D->GetDesc(&desc11);

        usage = desc11.Usage;
        format = desc11.Format;
        returnValue.isCPUWritable = (desc11.CPUAccessFlags & D3D11_CPU_ACCESS_WRITE) != 0;
        returnValue.isRenderTarget = (desc11.BindFlags & (D3D11_BIND_RENDER_TARGET | D3D11_BIND_DEPTH_STENCIL)) != 0;
        returnValue.isUAV = (desc11.BindFlags & D3D11_BIND_UNORDERED_ACCESS) != 0;
        returnValue.mipLevels = (uint32_t)desc11.MipLevels;
        returnValue.sampleCount = 1;
        returnValue.sampleQuality = 0;

        returnValue.isArray = false;
        returnValue.dimensions = Vector3u((uint32_t)desc11.Width, (uint32_t)desc11.Height, (uint32_t)desc11.Depth);
      }
      else
      {
        CHECK_ERROR(0, "Unknown texture type");
      }
    }

    
    switch (usage)
    {
    case D3D11_USAGE_DEFAULT: returnValue.usage = TextureDesc::USAGE_DEFAULT; break;
    case D3D11_USAGE_IMMUTABLE: returnValue.usage = TextureDesc::USAGE_IMMUTABLE; break;
    case D3D11_USAGE_DYNAMIC: returnValue.usage = TextureDesc::USAGE_DYNAMIC; break;
    case D3D11_USAGE_STAGING: CHECK_ERROR(0, "Staging resources aren't supported"); break;
    }

    switch (format)
    {
    case DXGI_FORMAT_R32_UINT: returnValue.format = TextureDesc::FORMAT_R32U; break;
	case DXGI_FORMAT_R11G11B10_FLOAT: returnValue.format = TextureDesc::FORMAT_R11G11B10F; break;
	case DXGI_FORMAT_R16G16B16A16_FLOAT: returnValue.format = TextureDesc::FORMAT_RGBA16F; break;
    case DXGI_FORMAT_R32G32B32A32_FLOAT: returnValue.format = TextureDesc::FORMAT_RGBA32F; break;
    case DXGI_FORMAT_R32_FLOAT: returnValue.format = TextureDesc::FORMAT_R32F; break;
    case DXGI_FORMAT_R8G8B8A8_UNORM: returnValue.format = TextureDesc::FORMAT_RGBA8_UNORM; break;
	case DXGI_FORMAT_R8G8B8A8_TYPELESS: returnValue.format = TextureDesc::FORMAT_RGBA8_UNORM; break;
	case DXGI_FORMAT_B8G8R8A8_UNORM: returnValue.format = TextureDesc::FORMAT_BGRA8_UNORM; break;
	case DXGI_FORMAT_B8G8R8A8_TYPELESS: returnValue.format = TextureDesc::FORMAT_BGRA8_UNORM; break;
	case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: returnValue.format = TextureDesc::FORMAT_SRGBA8_UNORM; break;
    case DXGI_FORMAT_R16G16B16A16_UNORM: returnValue.format = TextureDesc::FORMAT_RGBA16_UNORM; break;
    case DXGI_FORMAT_R10G10B10A2_UNORM: returnValue.format = TextureDesc::FORMAT_R10G10B10A2_UNORM; break;
    case DXGI_FORMAT_D16_UNORM: returnValue.format = TextureDesc::FORMAT_D16; break;
    case DXGI_FORMAT_D24_UNORM_S8_UINT: returnValue.format = TextureDesc::FORMAT_D24S8; break;
    case DXGI_FORMAT_R24G8_TYPELESS: returnValue.format = TextureDesc::FORMAT_D24S8; break;
    case DXGI_FORMAT_D32_FLOAT: returnValue.format = TextureDesc::FORMAT_D32; break;
      default:
        CHECK_ERROR(0, "This format is not supported");
    }

    return returnValue;
  }

  IRendererInterfaceD3D11::BufferObjectMap::value_type* IRendererInterfaceD3D11::getHandleForBuffer(ID3D11Buffer* resource, const BufferDesc* bufferDesc /*= NULL*/)
  {
    if (!resource) //if it's null, we want a null handle
      return NULL;

    BufferObjectMap::iterator it = buffers.find(resource);
    if (it == buffers.end())
    {
      it = buffers.insert(BufferObjectMap::value_type(resource, BufferViewSet())).first; //we haven't seen this one before

      //use our provided one or make one from the D3D data
      it->second.bufferDesc = bufferDesc ? *bufferDesc : getBufferDescFromD3D11Buffer(resource);
    }

    BufferObjectMap::value_type& mapValue = *it;
    return &mapValue;
  }

  BufferDesc IRendererInterfaceD3D11::getBufferDescFromD3D11Buffer(ID3D11Buffer* buffer)
  {
    D3D11_BUFFER_DESC desc11;
    buffer->GetDesc(&desc11);

    BufferDesc returnValue;
    returnValue.byteSize = (uint32_t)desc11.ByteWidth;
    returnValue.canHaveUAVs = (desc11.BindFlags & D3D11_BIND_UNORDERED_ACCESS) != 0;
    returnValue.isCPUWritable = (desc11.CPUAccessFlags & D3D11_CPU_ACCESS_WRITE) != 0;
    returnValue.isDrawIndirectArgs = (desc11.MiscFlags & D3D11_RESOURCE_MISC_DRAWINDIRECT_ARGS) != 0;
    returnValue.structStride = (desc11.MiscFlags & D3D11_RESOURCE_MISC_BUFFER_STRUCTURED) ? (uint32_t)desc11.StructureByteStride : 0;
    return returnValue;
  }

  ID3D11ShaderResourceView* IRendererInterfaceD3D11::getSRVForBuffer(BufferObjectMap::value_type* resource)
  {
    BufferViewSet& bufferData = resource->second;
    if (bufferData.shaderResourceView)
      return bufferData.shaderResourceView.Get();

    D3D11_SHADER_RESOURCE_VIEW_DESC desc11;
    desc11.ViewDimension = D3D11_SRV_DIMENSION_BUFFEREX;
    desc11.Format = bufferData.bufferDesc.structStride ? DXGI_FORMAT_UNKNOWN : DXGI_FORMAT_R32_UINT;
    desc11.BufferEx.FirstElement = 0;
    desc11.BufferEx.NumElements = bufferData.bufferDesc.byteSize / (bufferData.bufferDesc.structStride ? bufferData.bufferDesc.structStride : 4);
    desc11.BufferEx.Flags = 0;

    CHECK_ERROR(SUCCEEDED(device->CreateShaderResourceView(resource->first.Get(), &desc11, &bufferData.shaderResourceView)), "Creation failed");
    return bufferData.shaderResourceView.Get();
  }

  ID3D11UnorderedAccessView* IRendererInterfaceD3D11::getUAVForBuffer(BufferObjectMap::value_type* resource)
  {
    BufferViewSet& bufferData = resource->second;
    if (bufferData.unorderedAccessView)
      return bufferData.unorderedAccessView.Get();

    D3D11_UNORDERED_ACCESS_VIEW_DESC desc11;
    desc11.ViewDimension = D3D11_UAV_DIMENSION_BUFFER;
    desc11.Format = bufferData.bufferDesc.structStride ? DXGI_FORMAT_UNKNOWN : DXGI_FORMAT_R32_UINT;
    desc11.Buffer.FirstElement = 0;
    desc11.Buffer.NumElements = bufferData.bufferDesc.byteSize / (bufferData.bufferDesc.structStride ? bufferData.bufferDesc.structStride : 4);
    desc11.Buffer.Flags = 0;

    CHECK_ERROR(SUCCEEDED(device->CreateUnorderedAccessView(resource->first.Get(), &desc11, &bufferData.unorderedAccessView)), "Creation failed");
    return bufferData.unorderedAccessView.Get();
  }
  
  void IRendererInterfaceD3D11::forgetAboutTexture(ID3D11Resource* resource)
  {
    textures.erase(resource);
  }

  void IRendererInterfaceD3D11::forgetAboutBuffer(ID3D11Buffer* resource)
  {
    buffers.erase(resource);
  }

  void IRendererInterfaceD3D11::clearCachedData()
  {
    textures.clear();
    buffers.clear();
    states.clear();
  }

  bool IRendererInterfaceD3D11::getValidateStatesWithTheSameIDAreTheSame() const
  {
    return validateStatesWithTheSameIDAreTheSame;
  }

  void IRendererInterfaceD3D11::setValidateStatesWithTheSameIDAreTheSame(bool v)
  {
    validateStatesWithTheSameIDAreTheSame = v;
  }

  namespace 
  {
    //Unfortunately we can't memcmp the structs since they have padding bytes in them
    inline bool operator!=(const D3D11_RENDER_TARGET_BLEND_DESC& lhsrt, const D3D11_RENDER_TARGET_BLEND_DESC& rhsrt)
    {
      if (lhsrt.BlendEnable != rhsrt.BlendEnable ||
        lhsrt.SrcBlend != rhsrt.SrcBlend ||
        lhsrt.DestBlend != rhsrt.DestBlend ||
        lhsrt.BlendOp != rhsrt.BlendOp ||
        lhsrt.SrcBlendAlpha != rhsrt.SrcBlendAlpha ||
        lhsrt.DestBlendAlpha != rhsrt.DestBlendAlpha ||
        lhsrt.BlendOpAlpha != rhsrt.BlendOpAlpha ||
        lhsrt.RenderTargetWriteMask != rhsrt.RenderTargetWriteMask)
        return true;
      return false;
    }

    inline bool operator!=(const D3D11_BLEND_DESC& lhs, const D3D11_BLEND_DESC& rhs)
    {
      if (lhs.AlphaToCoverageEnable != rhs.AlphaToCoverageEnable ||
              lhs.IndependentBlendEnable != rhs.IndependentBlendEnable)
              return true;
      for (size_t i = 0; i < sizeof(lhs.RenderTarget) / sizeof(lhs.RenderTarget[0]); i++)
      {
        if (lhs.RenderTarget[i] != rhs.RenderTarget[i])
          return true;
      }
      return false;
    }

    inline bool operator!=(const D3D11_RASTERIZER_DESC& lhs, const D3D11_RASTERIZER_DESC& rhs)
    {
      if (lhs.FillMode != rhs.FillMode ||
        lhs.CullMode != rhs.CullMode ||
        lhs.FrontCounterClockwise != rhs.FrontCounterClockwise ||
        lhs.DepthBias != rhs.DepthBias ||
        lhs.DepthBiasClamp != rhs.DepthBiasClamp ||
        lhs.SlopeScaledDepthBias != rhs.SlopeScaledDepthBias ||
        lhs.DepthClipEnable != rhs.DepthClipEnable ||
        lhs.ScissorEnable != rhs.ScissorEnable ||
        lhs.MultisampleEnable != rhs.MultisampleEnable ||
        lhs.AntialiasedLineEnable != rhs.AntialiasedLineEnable)
        return true;
    
      return false;
    }

    inline bool operator!=(const D3D11_DEPTH_STENCILOP_DESC& lhs, const D3D11_DEPTH_STENCILOP_DESC& rhs)
    {
      if (lhs.StencilFailOp != rhs.StencilFailOp ||
        lhs.StencilDepthFailOp != rhs.StencilDepthFailOp ||
        lhs.StencilPassOp != rhs.StencilPassOp ||
        lhs.StencilFunc != rhs.StencilFunc)
        return true;
      return false;
    }
    inline bool operator!=(const D3D11_DEPTH_STENCIL_DESC& lhs, const D3D11_DEPTH_STENCIL_DESC& rhs)
    {
      if (lhs.DepthEnable != rhs.DepthEnable ||
        lhs.DepthWriteMask != rhs.DepthWriteMask ||
        lhs.DepthFunc != rhs.DepthFunc ||
        lhs.StencilEnable != rhs.StencilEnable ||
        lhs.StencilReadMask != rhs.StencilReadMask ||
        lhs.StencilWriteMask != rhs.StencilWriteMask ||
        lhs.FrontFace != rhs.FrontFace ||
        lhs.FrontFace != rhs.BackFace)
        return true;

      return false;
    }
  }

  const IRendererInterfaceD3D11::StateSet& IRendererInterfaceD3D11::getStateSet(const RenderState& renderState)
  {
    StateSet& currentSet = states[renderState.uniqueID];
    bool isNonCachedState = renderState.uniqueID == 0;

    if (currentSet.blendState == NULL || isNonCachedState || validateStatesWithTheSameIDAreTheSame)
    {
      const BlendState& blendState = renderState.blendState;

      D3D11_BLEND_DESC desc11New;
      desc11New.AlphaToCoverageEnable = blendState.alphaToCoverage ? TRUE : FALSE;
      //we always use this and set the states for each target explicitly
      desc11New.IndependentBlendEnable = TRUE;
      //we can have only 8 blend states but 16 viewports
      uint32_t blendCount = std::min(renderState.targetCount, (uint32_t)BlendState::MAX_MRT_BLEND_COUNT);
      for (uint32_t i = 0; i < blendCount; i++)
      {
        desc11New.RenderTarget[i].BlendEnable = blendState.blendEnable[i] ? TRUE : FALSE;
        desc11New.RenderTarget[i].SrcBlend = convertBlendValue(blendState.srcBlend[i]);
        desc11New.RenderTarget[i].DestBlend = convertBlendValue(blendState.destBlend[i]);
        desc11New.RenderTarget[i].BlendOp = convertBlendOp(blendState.blendOp[i]);
        desc11New.RenderTarget[i].SrcBlendAlpha = convertBlendValue(blendState.srcBlendAlpha[i]);
        desc11New.RenderTarget[i].DestBlendAlpha = convertBlendValue(blendState.destBlendAlpha[i]);
        desc11New.RenderTarget[i].BlendOpAlpha = convertBlendOp(blendState.blendOpAlpha[i]);
        desc11New.RenderTarget[i].RenderTargetWriteMask = (blendState.redMask[i] ? D3D11_COLOR_WRITE_ENABLE_RED : 0) |
          (blendState.greenMask[i] ? D3D11_COLOR_WRITE_ENABLE_GREEN : 0) |
          (blendState.blueMask[i] ? D3D11_COLOR_WRITE_ENABLE_BLUE : 0) |
          (blendState.alphaMask[i] ? D3D11_COLOR_WRITE_ENABLE_ALPHA : 0);
      }
      //Initalize this to default for our state compare here
      const D3D11_RENDER_TARGET_BLEND_DESC defaultRenderTargetBlendDesc =
      {
        FALSE,
        D3D11_BLEND_ONE, D3D11_BLEND_ZERO, D3D11_BLEND_OP_ADD,
        D3D11_BLEND_ONE, D3D11_BLEND_ZERO, D3D11_BLEND_OP_ADD,
        D3D11_COLOR_WRITE_ENABLE_ALL,
      };
      for (uint32_t i = blendCount; i < 8; i++)
        desc11New.RenderTarget[i] = defaultRenderTargetBlendDesc;

      if (currentSet.blendState != NULL)
      {
        D3D11_BLEND_DESC desc11Old;
        currentSet.blendState->GetDesc(&desc11Old);
        //is it the same as the one we have already?
        if (desc11Old != desc11New)
        {
          CHECK_ERROR(isNonCachedState, "This state is different than before is an is not state 0");
          currentSet.blendState.Reset(); //free it
        }
      }

      if (currentSet.blendState == NULL)
        CHECK_ERROR(SUCCEEDED(device->CreateBlendState(&desc11New, &currentSet.blendState)), "Creating blend state failed");
    }

    if (currentSet.depthState == NULL || isNonCachedState || validateStatesWithTheSameIDAreTheSame)
    {
      const DepthStencilState& depthState = renderState.depthStencilState;

      D3D11_DEPTH_STENCIL_DESC desc11New;
      desc11New.DepthEnable = depthState.depthEnable ? TRUE : FALSE;
      desc11New.DepthWriteMask = depthState.depthWriteMask == DepthStencilState::DEPTH_WRITE_MASK_ALL ? D3D11_DEPTH_WRITE_MASK_ALL : D3D11_DEPTH_WRITE_MASK_ZERO;
      desc11New.DepthFunc = convertComparisonFunc(depthState.depthFunc);
      desc11New.StencilEnable = depthState.stencilEnable ? TRUE : FALSE;
      desc11New.StencilReadMask = (UINT8)depthState.stencilReadMask;
      desc11New.StencilWriteMask = (UINT8)depthState.stencilWriteMask;
      desc11New.FrontFace.StencilFailOp = convertStencilOp(depthState.frontFace.stencilFailOp);
      desc11New.FrontFace.StencilDepthFailOp = convertStencilOp(depthState.frontFace.stencilDepthFailOp);
      desc11New.FrontFace.StencilPassOp = convertStencilOp(depthState.frontFace.stencilPassOp);
      desc11New.FrontFace.StencilFunc = convertComparisonFunc(depthState.frontFace.stencilFunc);
      desc11New.BackFace.StencilFailOp = convertStencilOp(depthState.backFace.stencilFailOp);
      desc11New.BackFace.StencilDepthFailOp = convertStencilOp(depthState.backFace.stencilDepthFailOp);
      desc11New.BackFace.StencilPassOp = convertStencilOp(depthState.backFace.stencilPassOp);
      desc11New.BackFace.StencilFunc = convertComparisonFunc(depthState.backFace.stencilFunc);
      if (currentSet.depthState != NULL)
      {
        D3D11_DEPTH_STENCIL_DESC desc11Old;
        currentSet.depthState->GetDesc(&desc11Old);

        //is it the same as the one we have already?
        if (desc11New != desc11Old)
        {
          CHECK_ERROR(isNonCachedState, "This state is different than before is an is not state 0");
          currentSet.depthState.Reset(); //free it
        }
      }

      if (currentSet.depthState == NULL)
        CHECK_ERROR(SUCCEEDED(device->CreateDepthStencilState(&desc11New, &currentSet.depthState)), "Creating depth-stencil state failed");
    }

    if (currentSet.rasterState == NULL || isNonCachedState || validateStatesWithTheSameIDAreTheSame)
    {
      const RasterState& rasterState = renderState.rasterState;

      D3D11_RASTERIZER_DESC desc11New;
      switch (rasterState.fillMode)
      {
      case RasterState::FILL_SOLID:
        desc11New.FillMode = D3D11_FILL_SOLID;
        break;
      case RasterState::FILL_LINE:
        desc11New.FillMode = D3D11_FILL_WIREFRAME;
        break;
      default:
        CHECK_ERROR(0, "Unknown fillMode");
      }

      switch (rasterState.cullMode)
      {
      case RasterState::CULL_BACK:
        desc11New.CullMode = D3D11_CULL_BACK;
        break;
      case RasterState::CULL_FRONT:
        desc11New.CullMode = D3D11_CULL_FRONT;
        break;
      case RasterState::CULL_NONE:
        desc11New.CullMode = D3D11_CULL_NONE;
        break;
      default:
        CHECK_ERROR(0, "Unknown cullMode");
      }

      desc11New.FrontCounterClockwise = rasterState.frontCounterClockwise ? TRUE : FALSE;
      desc11New.DepthBias = D3D11_DEFAULT_DEPTH_BIAS;
      desc11New.DepthBiasClamp = D3D11_DEFAULT_DEPTH_BIAS_CLAMP;
      desc11New.SlopeScaledDepthBias = D3D11_DEFAULT_SLOPE_SCALED_DEPTH_BIAS;
      desc11New.DepthClipEnable = rasterState.depthClipEnable ? TRUE : FALSE;
      desc11New.ScissorEnable = rasterState.scissorEnable ? TRUE : FALSE;
      desc11New.MultisampleEnable = rasterState.multisampleEnable ? TRUE : FALSE;
      desc11New.AntialiasedLineEnable = rasterState.antialiasedLineEnable ? TRUE : FALSE;
     
      bool extendedState = rasterState.conservativeRasterEnable || rasterState.forcedSampleCount || rasterState.programmableSamplePositionsEnable;

      if (currentSet.rasterState != NULL && !extendedState) // we cannot get a descriptor for the extended state
      {
        D3D11_RASTERIZER_DESC desc11Old;
        currentSet.rasterState->GetDesc(&desc11Old);

        //is it the same as the one we have already?
        if (desc11New != desc11Old)
        {
          CHECK_ERROR(isNonCachedState, "This cached state is different than before");
          currentSet.rasterState.Reset(); //free it
        }
      }

      if (currentSet.rasterState == NULL)
      {
        if(extendedState)
        {
          NvAPI_D3D11_RASTERIZER_DESC_EX descEx;
          memset(&descEx, 0, sizeof(descEx));
          memcpy(&descEx, &desc11New, sizeof(desc11New));

          descEx.ConservativeRasterEnable = rasterState.conservativeRasterEnable;
          descEx.ProgrammableSamplePositionsEnable = rasterState.programmableSamplePositionsEnable;
          descEx.SampleCount = rasterState.forcedSampleCount;
          descEx.ForcedSampleCount = rasterState.forcedSampleCount;
          memcpy(descEx.SamplePositionsX, rasterState.samplePositionsX, sizeof(rasterState.samplePositionsX));
          memcpy(descEx.SamplePositionsY, rasterState.samplePositionsY, sizeof(rasterState.samplePositionsY));

          CHECK_ERROR(NVAPI_OK == NvAPI_D3D11_CreateRasterizerState(device.Get(), &descEx, &currentSet.rasterState), "Creating extended rasterizer state failed");
        }
        else
        {
          CHECK_ERROR(SUCCEEDED(device->CreateRasterizerState(&desc11New, &currentSet.rasterState)), "Creating rasterizer state failed");
        }
      }
    }

    return currentSet;
  }

  D3D11_BLEND IRendererInterfaceD3D11::convertBlendValue(BlendState::BLEND_VALUE value)
  {
    switch (value)
    {
    case BlendState::BLEND_ZERO:
      return D3D11_BLEND_ZERO;
    case BlendState::BLEND_ONE:
      return D3D11_BLEND_ONE;
    case BlendState::BLEND_SRC_COLOR:
      return D3D11_BLEND_SRC_COLOR;
    case BlendState::BLEND_INV_SRC_COLOR:
      return D3D11_BLEND_INV_SRC_COLOR;
    case BlendState::BLEND_SRC_ALPHA:
      return D3D11_BLEND_SRC_ALPHA;
    case BlendState::BLEND_INV_SRC_ALPHA:
      return D3D11_BLEND_INV_SRC_ALPHA;
    case BlendState::BLEND_DEST_ALPHA:
      return D3D11_BLEND_DEST_ALPHA;
    case BlendState::BLEND_INV_DEST_ALPHA:
      return D3D11_BLEND_INV_DEST_ALPHA;
    case BlendState::BLEND_DEST_COLOR:
      return D3D11_BLEND_DEST_COLOR;
    case BlendState::BLEND_INV_DEST_COLOR:
      return D3D11_BLEND_INV_DEST_COLOR;
    case BlendState::BLEND_SRC_ALPHA_SAT:
      return D3D11_BLEND_SRC_ALPHA_SAT;
    case BlendState::BLEND_BLEND_FACTOR:
      return D3D11_BLEND_BLEND_FACTOR;
    case BlendState::BLEND_INV_BLEND_FACTOR:
      return D3D11_BLEND_INV_BLEND_FACTOR;
    case BlendState::BLEND_SRC1_COLOR:
      return D3D11_BLEND_SRC1_COLOR;
    case BlendState::BLEND_INV_SRC1_COLOR:
      return D3D11_BLEND_INV_SRC1_COLOR;
    case BlendState::BLEND_SRC1_ALPHA:
      return D3D11_BLEND_SRC1_ALPHA;
    case BlendState::BLEND_INV_SRC1_ALPHA:
      return D3D11_BLEND_INV_SRC1_ALPHA;
    default:
      CHECK_ERROR(0, "Unknown blend value");
      return D3D11_BLEND_ZERO;
    }
  }

  D3D11_BLEND_OP IRendererInterfaceD3D11::convertBlendOp(BlendState::BLEND_OP value)
  {
    switch (value)
    {
    case BlendState::BLEND_OP_ADD:
      return D3D11_BLEND_OP_ADD;
    case BlendState::BLEND_OP_SUBTRACT:
      return D3D11_BLEND_OP_SUBTRACT;
    case BlendState::BLEND_OP_REV_SUBTRACT:
      return D3D11_BLEND_OP_REV_SUBTRACT;
    case BlendState::BLEND_OP_MIN:
      return D3D11_BLEND_OP_MIN;
    case BlendState::BLEND_OP_MAX:
      return D3D11_BLEND_OP_MAX;
    default:
      CHECK_ERROR(0, "Unknown blend op");
      return D3D11_BLEND_OP_ADD;
    }
  }

  D3D11_STENCIL_OP IRendererInterfaceD3D11::convertStencilOp(DepthStencilState::STENCIL_OP value)
  {
    switch (value)
    {
    case DepthStencilState::STENCIL_OP_KEEP:
      return D3D11_STENCIL_OP_KEEP;
    case DepthStencilState::STENCIL_OP_ZERO:
      return D3D11_STENCIL_OP_ZERO;
    case DepthStencilState::STENCIL_OP_REPLACE:
      return D3D11_STENCIL_OP_REPLACE;
    case DepthStencilState::STENCIL_OP_INCR_SAT:
      return D3D11_STENCIL_OP_INCR_SAT;
    case DepthStencilState::STENCIL_OP_DECR_SAT:
      return D3D11_STENCIL_OP_DECR_SAT;
    case DepthStencilState::STENCIL_OP_INVERT:
      return D3D11_STENCIL_OP_INVERT;
    case DepthStencilState::STENCIL_OP_INCR:
      return D3D11_STENCIL_OP_INCR;
    case DepthStencilState::STENCIL_OP_DECR:
      return D3D11_STENCIL_OP_DECR;
    default:
      CHECK_ERROR(0, "Unknown stencil op");
      return D3D11_STENCIL_OP_KEEP;
    }
  }

  D3D11_COMPARISON_FUNC IRendererInterfaceD3D11::convertComparisonFunc(DepthStencilState::COMPARISON_FUNC value)
  {
    switch (value)
    {
    case DepthStencilState::COMPARISON_NEVER:
      return D3D11_COMPARISON_NEVER;
    case DepthStencilState::COMPARISON_LESS:
      return D3D11_COMPARISON_LESS;
    case DepthStencilState::COMPARISON_EQUAL:
      return D3D11_COMPARISON_EQUAL;
    case DepthStencilState::COMPARISON_LESS_EQUAL:
      return D3D11_COMPARISON_LESS_EQUAL;
    case DepthStencilState::COMPARISON_GREATER:
      return D3D11_COMPARISON_GREATER;
    case DepthStencilState::COMPARISON_NOT_EQUAL:
      return D3D11_COMPARISON_NOT_EQUAL;
    case DepthStencilState::COMPARISON_GREATER_EQUAL:
      return D3D11_COMPARISON_GREATER_EQUAL;
    case DepthStencilState::COMPARISON_ALWAYS:
      return D3D11_COMPARISON_ALWAYS;
    default:
      CHECK_ERROR(0, "Unknown comparison func");
      return D3D11_COMPARISON_NEVER;
    }
  }

  void IRendererInterfaceD3D11::executeRenderThreadCommand(IRenderThreadCommand* onCommand)
  {
    //we have a simple implementation
    onCommand->executeAndDispose();
  }

  void IRendererInterfaceD3D11::signalError(const char* file, int line, const char* errorDesc)
  {
    if (errorCB)
      errorCB->signalError(file, line, errorDesc);
    else
      fprintf(stderr, "%s:%i %s\n", file, line, errorDesc);
  }

  D3D_PRIMITIVE_TOPOLOGY IRendererInterfaceD3D11::getPrimType(PrimitiveType::Enum pt)
  {
    //setup the primitive type
    switch (pt)
    {
    case PrimitiveType::POINT_LIST:
      return D3D_PRIMITIVE_TOPOLOGY_POINTLIST;
      break;
    case PrimitiveType::TRIANGLE_LIST:
      return D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
      break;
    case PrimitiveType::TRIANGLE_STRIP:
      return D3D_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP;
      break;
    default:
      CHECK_ERROR(0, "Unsupported type");
    }
    return D3D_PRIMITIVE_TOPOLOGY_UNDEFINED;
  }

  void IRendererInterfaceD3D11::disableSLIResouceSync(ID3D11Resource* resource)
  {
    (void)resource;
    return;
#if 0
    if (!nvapiIsInitalized)
      return;

    NVDX_ObjectHandle resouceHandle = nullptr;
    NvAPI_Status status = NvAPI_D3D_GetObjectHandleForResource(device.Get(), resource, &resouceHandle);
    CHECK_ERROR(status == NVAPI_OK, "NvAPI_D3D_GetObjectHandleForResource failed");
    //If the value is 1, the driver will not track any rendering operations that would mark this resource as dirty, 
    //!  avoiding any form of synchronization across frames rendered in parallel in multiple GPUs in AFR mode.
    NvU32 contentSyncMode = 1; 
    status = NvAPI_D3D_SetResourceHint(device.Get(), resouceHandle, NVAPI_D3D_SRH_CATEGORY_SLI, NVAPI_D3D_SRH_SLI_APP_CONTROLLED_INTERFRAME_CONTENT_SYNC, &contentSyncMode);
    CHECK_ERROR(status == NVAPI_OK, "NvAPI_D3D_SetResourceHint failed");
#endif
  }

  uint32_t IRendererInterfaceD3D11::getAFRGroupOfCurrentFrameForSLI(uint32_t maxNumAFRGroups)
  {
    if (!nvapiIsInitalized)
      return 0; //No NVAPI

    NV_GET_CURRENT_SLI_STATE sliState = { 0 };
    sliState.version = NV_GET_CURRENT_SLI_STATE_VER;
    if (NvAPI_D3D_GetCurrentSLIState(device.Get(), &sliState) != NVAPI_OK)
    {
      CHECK_ERROR(false, "NvAPI_D3D_GetCurrentSLIState failed");
      return 0;
    }

    CHECK_ERROR(sliState.maxNumAFRGroups == maxNumAFRGroups, "Mismatched AFR group count");
    return sliState.currentAFRIndex;
  }

#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

#define SAFE_RELEASE_ARRAY(A)\
    for (uint32_t i = 0; i < ARRAYSIZE(A); ++i) SAFE_RELEASE(A[i]);

#define D3D11_GET_ARRAY(METHOD,A)\
    context->METHOD(0, ARRAYSIZE(A), A);

#define D3D11_SET_AND_RELEASE_ARRAY(METHOD,A)\
    context->METHOD(0, ARRAYSIZE(A), A);\
    SAFE_RELEASE_ARRAY(A);

  void UserState::save(ID3D11DeviceContext* context)
  {
    memset(this, 0, sizeof(*this));

    context->IAGetInputLayout(&pInputLayout);
    context->IAGetIndexBuffer(&pIndexBuffer, &IBFormat, &IBOffset);
    context->IAGetPrimitiveTopology(&primitiveTopology);

    numViewports = ARRAYSIZE(viewports);
    context->RSGetViewports(&numViewports, viewports);

    numScissorRects = ARRAYSIZE(scissorRects);
    context->RSGetScissorRects(&numScissorRects, scissorRects);

    context->RSGetState(&pRS);

    context->VSGetShader(&pVS, NULL, 0);
    context->GSGetShader(&pGS, NULL, 0);
    context->PSGetShader(&pPS, NULL, 0);
    context->CSGetShader(&pCS, NULL, 0);

    D3D11_GET_ARRAY(VSGetConstantBuffers, constantBuffersVS);
    D3D11_GET_ARRAY(VSGetShaderResources, shaderResourceViewsVS);
    D3D11_GET_ARRAY(VSGetSamplers, samplersVS);

    D3D11_GET_ARRAY(GSGetConstantBuffers, constantBuffersGS);
    D3D11_GET_ARRAY(GSGetShaderResources, shaderResourceViewsGS);
    D3D11_GET_ARRAY(GSGetSamplers, samplersGS);

    D3D11_GET_ARRAY(PSGetConstantBuffers, constantBuffersPS);
    D3D11_GET_ARRAY(PSGetShaderResources, shaderResourceViewsPS);
    D3D11_GET_ARRAY(PSGetSamplers, samplersPS);

    D3D11_GET_ARRAY(CSGetConstantBuffers, constantBuffersCS);
    D3D11_GET_ARRAY(CSGetShaderResources, shaderResourceViewsCS);
    D3D11_GET_ARRAY(CSGetSamplers, samplersCS);
    D3D11_GET_ARRAY(CSGetUnorderedAccessViews, unorderedAccessViewsCS);

    context->OMGetBlendState(&pBlendState, blendFactor, &sampleMask);
    context->OMGetDepthStencilState(&pDepthStencilState, &stencilRef);
    context->OMGetRenderTargets(ARRAYSIZE(pRTVs), pRTVs, &pDSV);
  }

  void UserState::restore(ID3D11DeviceContext* context)
  {
    context->IASetInputLayout(pInputLayout);
    SAFE_RELEASE(pInputLayout);

    context->IASetIndexBuffer(pIndexBuffer, IBFormat, IBOffset);
    SAFE_RELEASE(pIndexBuffer);

    context->IASetPrimitiveTopology(primitiveTopology);

    context->RSSetViewports(numViewports, viewports);
    context->RSSetScissorRects(numScissorRects, scissorRects);

    context->RSSetState(pRS);
    SAFE_RELEASE(pRS);

    context->VSSetShader(pVS, NULL, 0);
    context->GSSetShader(pGS, NULL, 0);
    context->PSSetShader(pPS, NULL, 0);
    context->CSSetShader(pCS, NULL, 0);
    SAFE_RELEASE(pVS);
    SAFE_RELEASE(pGS);
    SAFE_RELEASE(pPS);
    SAFE_RELEASE(pCS);

    D3D11_SET_AND_RELEASE_ARRAY(VSSetConstantBuffers, constantBuffersVS);
    D3D11_SET_AND_RELEASE_ARRAY(VSSetShaderResources, shaderResourceViewsVS);
    D3D11_SET_AND_RELEASE_ARRAY(VSSetSamplers, samplersVS);

    D3D11_SET_AND_RELEASE_ARRAY(GSSetConstantBuffers, constantBuffersGS);
    D3D11_SET_AND_RELEASE_ARRAY(GSSetShaderResources, shaderResourceViewsGS);
    D3D11_SET_AND_RELEASE_ARRAY(GSSetSamplers, samplersGS);

    D3D11_SET_AND_RELEASE_ARRAY(PSSetConstantBuffers, constantBuffersPS);
    D3D11_SET_AND_RELEASE_ARRAY(PSSetShaderResources, shaderResourceViewsPS);
    D3D11_SET_AND_RELEASE_ARRAY(PSSetSamplers, samplersPS);

    D3D11_SET_AND_RELEASE_ARRAY(CSSetConstantBuffers, constantBuffersCS);
    D3D11_SET_AND_RELEASE_ARRAY(CSSetShaderResources, shaderResourceViewsCS);
    D3D11_SET_AND_RELEASE_ARRAY(CSSetSamplers, samplersCS);

    UINT pUAVInitialCounts[D3D11_PS_CS_UAV_REGISTER_COUNT] = { 0 };
    context->CSSetUnorderedAccessViews(0, ARRAYSIZE(unorderedAccessViewsCS), unorderedAccessViewsCS, pUAVInitialCounts);
    SAFE_RELEASE_ARRAY(unorderedAccessViewsCS);

    context->OMSetBlendState(pBlendState, blendFactor, sampleMask);
    context->OMSetDepthStencilState(pDepthStencilState, stencilRef);
    SAFE_RELEASE(pBlendState);
    SAFE_RELEASE(pDepthStencilState);

    context->OMSetRenderTargets(ARRAYSIZE(pRTVs), pRTVs, pDSV);
    SAFE_RELEASE_ARRAY(pRTVs);
    SAFE_RELEASE(pDSV);
  }

} // namespace Util
} // namespace VXGI
