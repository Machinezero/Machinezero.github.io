/* 
* Copyright (c) 2012-2014, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#pragma once

struct ID3D11Buffer;
struct ID3D11Texture2D;
struct ID3D11ShaderResourceView;
struct ID3D11RenderTargetView;
struct ID3D11DepthStencilView;
struct ID3D11UnorderedAccessView;

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if (p) { (p)->Release(); (p)=0; } }
#endif

#ifndef V_RETURN
#define V_RETURN(x)    { hr = (x); if( FAILED(hr) ) { return hr; } }
#endif

template <typename T>
class D3DResource
{
public:
    D3DResource()
        : pResource(0)
        , pSRV(0)
        , pRTV(0)
        , pDSV(0)
        , pUAV(0)
    { }

    D3DResource(const D3DResource& r)
    {
        pResource = r.pResource; if (pResource) pResource->AddRef();
        pSRV = r.pSRV; if (pSRV) pSRV->AddRef();
        pRTV = r.pRTV; if (pRTV) pRTV->AddRef();
        pDSV = r.pDSV; if (pDSV) pDSV->AddRef();
        pUAV = r.pUAV; if (pUAV) pUAV->AddRef();
    }

    void operator=(const D3DResource& r)
    {
        pResource = r.pResource; if (pResource) pResource->AddRef();
        pSRV = r.pSRV; if (pSRV) pSRV->AddRef();
        pRTV = r.pRTV; if (pRTV) pRTV->AddRef();
        pDSV = r.pDSV; if (pDSV) pDSV->AddRef();
        pUAV = r.pUAV; if (pUAV) pUAV->AddRef();
    }

    void Release()
    {
        SAFE_RELEASE(pResource);
        SAFE_RELEASE(pSRV);
        SAFE_RELEASE(pRTV);
        SAFE_RELEASE(pDSV);
        SAFE_RELEASE(pUAV);
    }

    ~D3DResource()
    {
        Release();
    }

    T* pResource;
    ID3D11ShaderResourceView*   pSRV;
    ID3D11RenderTargetView*     pRTV;
    ID3D11DepthStencilView*     pDSV;
    ID3D11UnorderedAccessView*  pUAV;
};

typedef D3DResource<ID3D11Texture2D>    Texture2D;
typedef D3DResource<ID3D11Buffer>       Buffer;