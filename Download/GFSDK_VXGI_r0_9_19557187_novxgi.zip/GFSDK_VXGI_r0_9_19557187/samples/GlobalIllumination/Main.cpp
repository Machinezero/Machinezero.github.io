/* 
* Copyright (c) 2012-2014, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#include "SceneRenderer.h"

#include "Camera.h"
#include "DeviceManager.h"
#include <AntTweakBar.h>

using namespace DirectX;

CFirstPersonCamera              g_Camera;
CModelViewerCamera              g_LightCamera;
DeviceManager*                  g_DeviceManager = NULL;

SceneRenderer*                  g_pSceneRenderer            = NULL;                     

static float g_fCameraClipNear  = 1.0f;
static float g_fCameraClipFar   = 10000.0f;
static float g_fAmbientScale    = 0.1f;
static float g_fDiffuseScale    = 1.0f;
static float g_fSpecularScale   = 1.0f;
static float g_fLightSize       = 2500.0f;
static bool g_bRenderHUD        = true;
static bool g_bInitialized      = false;
static int frameCount = 0;

static float x = -1.0f, y = -0.55f, z = 0.38f;

static bool autoAnimate = false;


class AntTweakBarVisualController : public IVisualController
{
	virtual LRESULT MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
		if (g_bRenderHUD || uMsg == WM_KEYDOWN || uMsg == WM_CHAR)
			if (TwEventWin(hWnd, uMsg, wParam, lParam))
			{
				return 0; // Event has been handled by AntTweakBar
			}

		return 1;
	}

	void RenderText()
	{
		TwBeginText(2, 0, 0, 0);
		const unsigned int color = 0xffffc0ff;
		char msg[256];

		double averageTime = g_DeviceManager->GetAverageFrameTime();
		double fps = (averageTime > 0) ? 1.0 / averageTime : 0.0;

		sprintf_s(msg, "%.1f FPS", fps);
		TwAddTextLine(msg, color, 0);

		TwEndText();
	}

	virtual void Render(ID3D11Device*, ID3D11DeviceContext*, ID3D11RenderTargetView*, ID3D11DepthStencilView*)
	{
		if (g_bRenderHUD)
		{
			RenderText();
			TwDraw();
		}
	}

	virtual HRESULT DeviceCreated(ID3D11Device* pDevice)
	{
		TwInit(TW_DIRECT3D11, pDevice);
		InitDialogs();
		return S_OK;
	}

	virtual void DeviceDestroyed()
	{
		TwTerminate();
	}

	virtual void BackBufferResized(ID3D11Device* pDevice, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc)
	{
		(void)pDevice;
		TwWindowSize(pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height);
	}

	void InitDialogs()
	{
		TwBar* bar = TwNewBar("barMain");
		TwDefine("barMain label='Settings' size='250 300' valueswidth=100");

		TwAddVarRW(bar, "LightSize", TW_TYPE_FLOAT, &g_fLightSize, "min=1 max=20000 step=100");
		TwAddVarRW(bar, "LightDirectionX", TW_TYPE_FLOAT, &x, "min=-1 max=1 step=0.01");
		TwAddVarRW(bar, "LightDirectionY", TW_TYPE_FLOAT, &y, "min=-1 max=1 step=0.01");
		TwAddVarRW(bar, "LightDirectionZ", TW_TYPE_FLOAT, &z, "min=-1 max=1 step=0.01");
		TwAddVarRW(bar, "Light Animation", TW_TYPE_BOOLCPP, &autoAnimate, "");
	}
};

class MainVisualController: public IVisualController
{
    virtual LRESULT MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
    { 
        g_LightCamera.HandleMessages( hWnd, uMsg, wParam, lParam );
        g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

        return 1;
    }

	virtual void Animate(double fElapsedTimeSeconds)
	{
		float time = (frameCount++ % 1000)*(0.001 * 2 * 3.14);

		g_Camera.FrameMove((float)fElapsedTimeSeconds);

		g_LightCamera.FrameMove((float)fElapsedTimeSeconds);

		XMVECTOR lightDir = g_LightCamera.GetLookAtPt() - g_LightCamera.GetEyePt();

		if (autoAnimate) {

			x = cos(time);
			z = cos(time);//abs(sin(frameCount / time));
			y = -abs(sin(time));
		}
		g_pSceneRenderer->SetLightDirection(VXGI::Vector3f(x, y, z));
		//g_pSceneRenderer->SetLightDirection(lightDir.m128_f32);
	}

    virtual void Render(ID3D11Device*, ID3D11DeviceContext* pDeviceContext, ID3D11RenderTargetView* pRTV, ID3D11DepthStencilView* pDSV) 
    { 
        const float Black[4] = {0};
        pDeviceContext->ClearRenderTargetView(pRTV, Black);
        pDeviceContext->ClearDepthStencilView(pDSV, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

        XMVECTOR eyePt = g_Camera.GetEyePt();
        XMVECTOR viewForward = g_Camera.GetWorldAhead();
        XMMATRIX viewMatrix = g_Camera.GetViewMatrix();
        XMMATRIX projMatrix = g_Camera.GetProjMatrix();
        XMMATRIX viewProjMatrixXM = viewMatrix * projMatrix;
        VXGI::Matrix4f viewProjMatrix = *reinterpret_cast<VXGI::Matrix4f*>(&viewProjMatrixXM);

        // shadow map
        g_pSceneRenderer->RenderShadowMap(pDeviceContext, VXGI::Vector3f(0.f), g_fLightSize);

        // Depth-only pass
        g_pSceneRenderer->RenderDepth(pDeviceContext, viewProjMatrix);

        // G-Buffer attributes
        g_pSceneRenderer->RenderAttributes(pDeviceContext, viewProjMatrix);

        VXGI::IViewTracer::InputBuffers inputBuffers;
        g_pSceneRenderer->FillTracingInputBuffers(inputBuffers);
        memcpy(&inputBuffers.viewMatrix, &viewMatrix, sizeof(viewMatrix));
        memcpy(&inputBuffers.projMatrix, &projMatrix, sizeof(projMatrix));

        VXGI::TextureHandle indirectDiffuse = NULL;
        VXGI::TextureHandle indirectSpecular = NULL;
        VXGI::Vector3f ambientColor(g_fAmbientScale);

        g_pSceneRenderer->Shade(indirectDiffuse, indirectSpecular, pRTV, viewProjMatrix, ambientColor * 0.5f);
       

    }

    virtual HRESULT DeviceCreated(ID3D11Device* pDevice)
    {
        HRESULT hr;
    
        ID3D11DeviceContext* pImmediateContext;
        pDevice->GetImmediateContext(&pImmediateContext);

        g_pSceneRenderer = new SceneRenderer(pImmediateContext);

        if(FAILED(g_pSceneRenderer->LoadMesh(pDevice, "..\\..\\media\\Sponza\\SponzaNoFlag.obj")))
          if(FAILED(g_pSceneRenderer->LoadMesh(pDevice, "..\\media\\Sponza\\SponzaNoFlag.obj")))
            return E_FAIL;

        V_RETURN( g_pSceneRenderer->AllocateResources(pDevice) );

        g_bInitialized = true;

        return S_OK;
    }
    
    virtual void DeviceDestroyed() 
    {   
        if(g_pSceneRenderer)
        {
            g_pSceneRenderer->ReleaseViewDependentResources();
            g_pSceneRenderer->ReleaseResources();
        }

        if(g_pSceneRenderer)
        {
          delete g_pSceneRenderer;
          g_pSceneRenderer = NULL;
        }
    }
    
    virtual void BackBufferResized(ID3D11Device* pDevice, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc) 
    {     
        TwWindowSize(pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height);

        g_pSceneRenderer->ReleaseViewDependentResources();

        g_pSceneRenderer->AllocateViewDependentResources( 
            pDevice, pBackBufferSurfaceDesc->Width,
            pBackBufferSurfaceDesc->Height,
            pBackBufferSurfaceDesc->SampleDesc.Count );

        // Setup the camera's projection parameters    
        float fAspectRatio = pBackBufferSurfaceDesc->Width / ( FLOAT )pBackBufferSurfaceDesc->Height;
        g_Camera.SetProjParams( XM_PIDIV4, fAspectRatio, g_fCameraClipNear, g_fCameraClipFar );

        // Setup the light camera's projection params
        g_LightCamera.SetProjParams( XM_PIDIV4, 1.0f, g_fCameraClipNear, g_fCameraClipFar );
        g_LightCamera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
        g_LightCamera.SetButtonMasks( MOUSE_RIGHT_BUTTON, MOUSE_WHEEL, MOUSE_RIGHT_BUTTON );
    }
};


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
    (void)hInstance;
    (void)hPrevInstance;
    (void)lpCmdLine;
    (void)nCmdShow;

    g_DeviceManager = new DeviceManager();

    MainVisualController sceneController;
	AntTweakBarVisualController atbController;

    g_DeviceManager->AddControllerToFront(&sceneController);
	g_DeviceManager->AddControllerToFront(&atbController);

    DeviceCreationParameters deviceParams;
    deviceParams.swapChainFormat = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
    deviceParams.swapChainSampleCount = 1;
    deviceParams.startFullscreen = false;
    deviceParams.backBufferWidth = 1280;
    deviceParams.backBufferHeight = 800;
#ifdef DEBUG
    deviceParams.createDeviceFlags = D3D11_CREATE_DEVICE_DEBUG;
#endif
    
    if(FAILED(g_DeviceManager->CreateWindowDeviceAndSwapChain(deviceParams, L"VXGI Sample: Basic Global Illumination")))
    {
        MessageBox(NULL, L"Cannot initialize the D3D11 device with the requested parameters", L"Error", MB_OK | MB_ICONERROR);
        return 1;
    }
    
    XMVECTOR eyePt = XMVectorSet(0.0f, 100.0f, 50.0f, 0);
    XMVECTOR lookAtPt = XMVectorSet(-100.0f, 100.0f, 50.0f, 0);
    g_Camera.SetViewParams(eyePt, lookAtPt);
    g_Camera.SetScalers(0.005f, 500.0f);
    g_Camera.SetRotateButtons(true, false, false, false);

    eyePt = XMVectorSet(20.0f, 30.0f, -2.0f, 0);
    lookAtPt = XMVectorSet(0, 0, 0, 0);
    g_LightCamera.SetViewParams(eyePt, lookAtPt);
    g_LightCamera.SetScalers(0.00025f, 100.0f);
    
    if(g_bInitialized)
        g_DeviceManager->MessageLoop();

    g_DeviceManager->Shutdown();
    delete g_DeviceManager;

    return 0;
}