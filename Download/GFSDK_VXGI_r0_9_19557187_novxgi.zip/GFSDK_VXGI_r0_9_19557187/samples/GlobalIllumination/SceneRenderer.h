/* 
* Copyright (c) 2012-2014, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#pragma once

#include "GI_Interface.h"
#include "D3DHelper.h"
#include "Scene.h"
#include <Windows.h>
#include <functional>
#include "../../GIWorks/examplecode/GI_InterfaceD3D11.h"

#pragma warning(disable : 4324)

__declspec(align(16)) struct GlobalConstants
{
    VXGI::Matrix4f viewProjMatrix;
    VXGI::Matrix4f viewProjMatrixInv;
    VXGI::Matrix4f lightMatrix;
    VXGI::Vector4f lightDirection;
    VXGI::Vector4f diffuseColor;
    VXGI::Vector4f lightColor;
    VXGI::Vector4f ambientColor;
    float rShadowMapSize;
    uint32_t enableIndirectDiffuse;
    uint32_t enableIndirectSpecular;
};


struct MeshMaterialInfo: public VXGI::MaterialInfo 
{
    ID3D11ShaderResourceView*   diffuseTexture;
    ID3D11ShaderResourceView*   specularTexture;
    ID3D11ShaderResourceView*   normalsTexture;
    VXGI::Vector3f              diffuseColor;

    MeshMaterialInfo(): 
        diffuseTexture(NULL), 
        specularTexture(NULL),
        normalsTexture(NULL),
        diffuseColor(0.f)
    {}
};

typedef std::function<void(const MeshMaterialInfo&)> MaterialCallback;

class SceneRenderer :
  public VXGI::IErrorCallback
{
private:

    Scene*                  m_pScene;

    ID3D11DeviceContext*    m_pImmediateContext;

    VXGI::Util::IRendererInterfaceD3D11 m_RendererInterface;

    ID3D11InputLayout*      m_pInputLayout;
    ID3D11VertexShader*     m_pDefaultVS;
    ID3D11VertexShader*     m_pFullScreenQuadVS;

    ID3D11PixelShader*      m_pAttributesPS;
    ID3D11PixelShader*      m_pBlitPS;
    ID3D11PixelShader*      m_pCompositingPS;

    ID3D11Buffer*           m_pGlobalCBuffer;

    ID3D11RasterizerState*  m_pShadowRasterizerState;

    ID3D11SamplerState*     m_pDefaultSamplerState;
    ID3D11SamplerState*     m_pComparisonSamplerState;

    ID3D11DepthStencilState* m_pReadOnlyDepthStencilState;

    UINT                    m_Width;
    UINT                    m_Height;
    UINT                    m_SampleCount;

    VXGI::Vector3f          m_LightDirection;
    VXGI::Matrix4f          m_LightViewMatrix;
    VXGI::Matrix4f          m_LightProjMatrix;
    VXGI::Matrix4f          m_LightViewProjMatrix;

    Texture2D               m_TargetAlbedo;
    Texture2D               m_TargetNormal;
    Texture2D               m_TargetDepth;

    Texture2D               m_ShadowMap;

public:
    SceneRenderer(ID3D11DeviceContext* pContext);
    
    VXGI::Util::IRendererInterfaceD3D11* GetRendererInterface() { return &m_RendererInterface; }

    HRESULT LoadMesh( ID3D11Device* pd3dDevice, const char* strFileName );

    HRESULT AllocateResources( ID3D11Device* pd3dDevice );
    HRESULT AllocateViewDependentResources( ID3D11Device *device, UINT width, UINT height, UINT sampleCount = 1);
    void ReleaseResources();
    void ReleaseViewDependentResources();

    void RenderGeometry( ID3D11DeviceContext *pContext, const VXGI::Matrix4f& viewProjMatrix );
    void RenderDepth( ID3D11DeviceContext *pContext, const VXGI::Matrix4f& viewProjMatrix );
    void RenderAttributes( ID3D11DeviceContext *pContext, const VXGI::Matrix4f& viewProjMatrix );

    void SetLightDirection( VXGI::Vector3f direction );
    void RenderShadowMap( ID3D11DeviceContext *pContext, const VXGI::Vector3f cameraPosition, float lightSize );

    void GetMaterialInfo(UINT meshID, OUT MeshMaterialInfo& materialInfo);
    
    void FillTracingInputBuffers(VXGI::IViewTracer::InputBuffers& inputBuffers);
    VXGI::TextureHandle GetAlbedoBufferHandle();

    void Blit(VXGI::TextureHandle source, ID3D11RenderTargetView* pDestRTV);
    void Shade(VXGI::TextureHandle indirectDiffuse, VXGI::TextureHandle indirectSpecular, ID3D11RenderTargetView* pDestRTV, const VXGI::Matrix4f& viewProjMatrix, VXGI::Vector3f ambientColor);

    void RenderSceneCommon(
      const VXGI::Box3f *clippingBoxes,
      uint32_t numBoxes,
      const VXGI::Matrix4f& viewProjMatrix,
      MaterialCallback* onChangeMaterial);

    VXGI::LightDesc GetLightDesc();

    // IErrorCallback implementation

    virtual void signalError(const char* file, int line, const char* errorDesc);
};