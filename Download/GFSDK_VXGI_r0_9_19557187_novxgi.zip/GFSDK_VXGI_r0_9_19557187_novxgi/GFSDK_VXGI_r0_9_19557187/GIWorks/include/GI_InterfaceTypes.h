/* 
* Copyright (c) 2012-2015, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#ifndef GI_INTERFACETYPES_H_
#define GI_INTERFACETYPES_H_

#include "GI_Types.h"

GI_BEGIN_PACKING
namespace VXGI
{
  class IRenderThreadCommand;

  //////////////////////////////////////////////////////////////////////////
  // Texture
  //////////////////////////////////////////////////////////////////////////

  class Texture;
  typedef Texture* TextureHandle;

  struct TextureDesc
  {
    enum Format
    {
      FORMAT_R32U,
      FORMAT_RGBA16F,
      FORMAT_RGBA32F,
      FORMAT_R32F,
      FORMAT_RGBA8_UNORM,
      FORMAT_BGRA8_UNORM,
      FORMAT_SRGBA8_UNORM,
      FORMAT_RGBA16_UNORM,
      FORMAT_R10G10B10A2_UNORM,
      FORMAT_R11G11B10F,
      FORMAT_RG16F,
      FORMAT_D16,
      FORMAT_D24S8,
      FORMAT_D32,
      FORMAT_BC1_UNORM,
      FORMAT_BC2_UNORM,
      FORMAT_BC3_UNORM,
      FORMAT_BC1_UNORM_SRGB,
      FORMAT_BC2_UNORM_SRGB,
      FORMAT_BC3_UNORM_SRGB,
    };

    enum Usage
    {
      USAGE_DEFAULT,
      USAGE_IMMUTABLE,
      USAGE_DYNAMIC
    };
    Vector3u dimensions;
    uint32_t mipLevels;
    uint32_t sampleCount, sampleQuality;
    Format format;
    Usage usage;
    const char* debugName;

    bool isArray; //3D or array if .z != 0?
    bool isCubeMap;
    bool isRenderTarget;
    bool isUAV;
    bool isCPUWritable;
    bool disableSLISync;

    TextureDesc() :
      format((Format)(0)),
      dimensions(0,0,0),
      mipLevels(1),
      usage(USAGE_DEFAULT),
      sampleCount(1),
      sampleQuality(0),
      debugName(0),
      isCPUWritable(false),
      isUAV(false),
      isRenderTarget(false),
      isArray(false),
      isCubeMap(false),
      disableSLISync(false)
    {
    }
  };

  //////////////////////////////////////////////////////////////////////////
  // Buffer
  //////////////////////////////////////////////////////////////////////////

  class Buffer;
  typedef Buffer* BufferHandle;

  struct BufferDesc
  {
    //LM: Notice that there are no atomic/append/consume buffer-related things here.
    //We should use another UAV of uints instead since you can do that in both DX and GL
    //and that's what the driver is doing internally anyway
    uint32_t byteSize;
    uint32_t structStride; //if non-zero it's structured
    bool canHaveUAVs;
    bool isCPUWritable;
    bool isDrawIndirectArgs;
    bool disableSLISync;

    BufferDesc()  { memset(this, 0, sizeof(*this)); }
  };

  //////////////////////////////////////////////////////////////////////////
  // Constant Buffer
  //////////////////////////////////////////////////////////////////////////

  class ConstantBuffer;
  typedef ConstantBuffer* ConstantBufferHandle;

  struct ConstantBufferDesc
  {
    uint32_t byteSize;

    ConstantBufferDesc(uint32_t size) : byteSize(size) {}
    ConstantBufferDesc()  { memset(this, 0, sizeof(*this)); }
  };


  //////////////////////////////////////////////////////////////////////////
  // Shader
  //////////////////////////////////////////////////////////////////////////

  class Shader;
  typedef Shader* ShaderHandle;

  struct ShaderDesc
  {
    enum SHADER_TYPE { SHADER_VERTEX, SHADER_HULL, SHADER_DOMAIN, SHADER_GEOMETRY, SHADER_PIXEL, SHADER_COMPUTE };
    SHADER_TYPE type;
    IRenderThreadCommand* preCreationCommand;
    IRenderThreadCommand* postCreationCommand;
    ShaderDesc()  { memset(this, 0, sizeof(*this)); }
  };

  //////////////////////////////////////////////////////////////////////////
  // Lights
  //////////////////////////////////////////////////////////////////////////

  class Light;
  typedef Light* LightHandle;

  //////////////////////////////////////////////////////////////////////////
  // Blend State
  //////////////////////////////////////////////////////////////////////////

  struct BlendState
  {
    enum { MAX_MRT_BLEND_COUNT = 8 };

    enum BLEND_VALUE
    {
      BLEND_ZERO	= 1,
      BLEND_ONE	= 2,
      BLEND_SRC_COLOR	= 3,
      BLEND_INV_SRC_COLOR	= 4,
      BLEND_SRC_ALPHA	= 5,
      BLEND_INV_SRC_ALPHA	= 6,
      BLEND_DEST_ALPHA	= 7,
      BLEND_INV_DEST_ALPHA	= 8,
      BLEND_DEST_COLOR	= 9,
      BLEND_INV_DEST_COLOR	= 10,
      BLEND_SRC_ALPHA_SAT	= 11,
      BLEND_BLEND_FACTOR	= 14,
      BLEND_INV_BLEND_FACTOR	= 15,
      BLEND_SRC1_COLOR	= 16,
      BLEND_INV_SRC1_COLOR	= 17,
      BLEND_SRC1_ALPHA	= 18,
      BLEND_INV_SRC1_ALPHA	= 19
    };
    
    enum BLEND_OP
    {
      BLEND_OP_ADD	= 1,
      BLEND_OP_SUBTRACT	= 2,
      BLEND_OP_REV_SUBTRACT	= 3,
      BLEND_OP_MIN	= 4,
      BLEND_OP_MAX	= 5
    };

    bool blendEnable[MAX_MRT_BLEND_COUNT];
    BLEND_VALUE srcBlend[MAX_MRT_BLEND_COUNT];
    BLEND_VALUE destBlend[MAX_MRT_BLEND_COUNT];
    BLEND_OP blendOp[MAX_MRT_BLEND_COUNT];
    BLEND_VALUE srcBlendAlpha[MAX_MRT_BLEND_COUNT];
    BLEND_VALUE destBlendAlpha[MAX_MRT_BLEND_COUNT];
    BLEND_OP blendOpAlpha[MAX_MRT_BLEND_COUNT];
    bool          redMask[MAX_MRT_BLEND_COUNT];
    bool          greenMask[MAX_MRT_BLEND_COUNT];
    bool          blueMask[MAX_MRT_BLEND_COUNT];
    bool          alphaMask[MAX_MRT_BLEND_COUNT];
    Vector4f      blendFactor;
    bool          alphaToCoverage;

    BlendState() : blendFactor(0, 0, 0, 0), alphaToCoverage(false) {
      for (unsigned int i = 0; i < MAX_MRT_BLEND_COUNT; i++) {
        blendEnable[i] = false;
        redMask[i] = true;
        greenMask[i] = true;
        blueMask[i] = true;
        alphaMask[i] = true;
        srcBlend[i] = BLEND_ONE;
        destBlend[i] = BLEND_ZERO;
        blendOp[i] = BLEND_OP_ADD;
        srcBlendAlpha[i] = BLEND_ONE;
        destBlendAlpha[i] = BLEND_ZERO;
        blendOpAlpha[i] = BLEND_OP_ADD;
      }
    }
  };

  //////////////////////////////////////////////////////////////////////////
  // Render State
  //////////////////////////////////////////////////////////////////////////

  struct RasterState
  {
    enum FILL_MODE
    {
      FILL_SOLID,
      FILL_LINE
    };

    enum CULL_MODE
    {
      CULL_BACK,
      CULL_FRONT,
      CULL_NONE
    };

    CULL_MODE cullMode;
    FILL_MODE fillMode;
    bool frontCounterClockwise;
    bool depthClipEnable;
    bool scissorEnable;
    bool multisampleEnable;
    bool antialiasedLineEnable;

    // Extended rasterizer state supported by Maxwell
    // In D3D11, use NvAPI_D3D11_CreateRasterizerState to create such rasterizer state.
    char forcedSampleCount;
    bool programmableSamplePositionsEnable;
    bool conservativeRasterEnable;
    char samplePositionsX[16];
    char samplePositionsY[16];

    RasterState()  {
      memset(this, 0, sizeof(RasterState));
      depthClipEnable = true;
    }
  };
  
  //////////////////////////////////////////////////////////////////////////
  // Depth Stencil State
  //////////////////////////////////////////////////////////////////////////

  struct DepthStencilState
  {
    enum DEPTH_WRITE_MASK
    {
      DEPTH_WRITE_MASK_ZERO	= 0,
      DEPTH_WRITE_MASK_ALL	= 1
    };

    enum STENCIL_OP
    {
      STENCIL_OP_KEEP	= 1,
      STENCIL_OP_ZERO	= 2,
      STENCIL_OP_REPLACE	= 3,
      STENCIL_OP_INCR_SAT	= 4,
      STENCIL_OP_DECR_SAT	= 5,
      STENCIL_OP_INVERT	= 6,
      STENCIL_OP_INCR	= 7,
      STENCIL_OP_DECR	= 8
    };

    enum COMPARISON_FUNC
    {
      COMPARISON_NEVER	= 1,
      COMPARISON_LESS	= 2,
      COMPARISON_EQUAL	= 3,
      COMPARISON_LESS_EQUAL	= 4,
      COMPARISON_GREATER	= 5,
      COMPARISON_NOT_EQUAL	= 6,
      COMPARISON_GREATER_EQUAL	= 7,
      COMPARISON_ALWAYS	= 8
    };

    struct StencilOpDesc
    {
      STENCIL_OP stencilFailOp;
      STENCIL_OP stencilDepthFailOp;
      STENCIL_OP stencilPassOp;
      COMPARISON_FUNC stencilFunc;
    };

    bool depthEnable;
    DEPTH_WRITE_MASK depthWriteMask;
    COMPARISON_FUNC depthFunc;
    bool stencilEnable;
    uint8_t stencilReadMask;
    uint8_t stencilWriteMask;
    StencilOpDesc frontFace;
    StencilOpDesc backFace;
    uint8_t stencilRefValue;

    DepthStencilState()  {
      stencilRefValue = 0;
      depthEnable = true;
      depthWriteMask = DEPTH_WRITE_MASK_ALL;
      depthFunc = COMPARISON_LESS;
      stencilEnable = false;
      stencilReadMask = uint8_t(0xff);
      stencilWriteMask = uint8_t(0xff);
      StencilOpDesc stencilOpDesc;
      stencilOpDesc.stencilFailOp = STENCIL_OP_KEEP;
      stencilOpDesc.stencilDepthFailOp = STENCIL_OP_KEEP;
      stencilOpDesc.stencilPassOp = STENCIL_OP_KEEP;
      stencilOpDesc.stencilFunc = COMPARISON_ALWAYS;
      frontFace = stencilOpDesc;
      backFace = stencilOpDesc;
    }
  };



  //////////////////////////////////////////////////////////////////////////
  // Sampler
  //////////////////////////////////////////////////////////////////////////

  class Sampler;
  typedef Sampler* SamplerHandle;

  struct SamplerDesc
  {
    enum WrapMode
    {
      WRAP_MODE_CLAMP,
      WRAP_MODE_WRAP,
      WRAP_MODE_BORDER,
      //etc
    };
    WrapMode wrapMode[3];
    float mipBias, anisotropy;
    bool minFilter, magFilter, mipFilter;
    bool shadowCompare;
    Vector4f borderColor;

    SamplerDesc()  { 
      minFilter = true;
      magFilter = true;
      mipFilter = true;
      wrapMode[0] = wrapMode[1] = wrapMode[2] = WRAP_MODE_CLAMP;
      mipBias = 0;
      anisotropy = 1;
      shadowCompare = false;
      borderColor = Vector4f(1,1,1,1);
    }
  };

  //////////////////////////////////////////////////////////////////////////
  // Render State (used by DrawCallState)
  //////////////////////////////////////////////////////////////////////////

  struct RenderState
  {
    enum { MAX_MRT_COUNT = 16, NO_UNIQUE_ID = 0 };

    TextureHandle targets[MAX_MRT_COUNT];
    //Cube face order:
    /*NR_CF_POSX
      NR_CF_NEGX
      NR_CF_POSY
      NR_CF_NEGY
      NR_CF_POSZ
      NR_CF_NEGZ*/

    uint32_t targetIndicies[MAX_MRT_COUNT]; //this is the array index, 3d-z, coord or cube face. For cube arrays, slice is /6, face is %6
    uint32_t targetMipSlices[MAX_MRT_COUNT];
    //These are in pixels
    Box3f    viewports[MAX_MRT_COUNT];
    Box2i    scissorRects[MAX_MRT_COUNT];
    uint32_t targetCount;

    TextureHandle depthTarget;
    uint32_t depthIndex;
    uint32_t depthMipSlice;

    Vector4f clearColor;
    float clearDepth;
    uint8_t clearStencil;

    bool clearColorTarget, clearDepthTarget, clearStencilTarget;

    //this is use for engine/APIs that have immutable state so that they can reuse their state blocks
    //this applies to blendState, depthStencilState, and rasterState
    uint32_t uniqueID; 

    BlendState blendState;
    DepthStencilState depthStencilState;
    RasterState rasterState;

    RenderState() : targetCount(0), clearColor(0,0,0,0), clearDepth(1.0f), clearStencil(0),
      clearColorTarget(false), clearDepthTarget(false), clearStencilTarget(false),
      depthTarget(0), depthIndex(0), depthMipSlice(0), uniqueID(NO_UNIQUE_ID)
    { 
      memset(targets, 0, sizeof(targets));
      memset(targetIndicies, 0, sizeof(targetIndicies));
      memset(targetMipSlices, 0, sizeof(targetMipSlices));
    }
  };

  template <typename T>
  struct Binding
  {
    T value;
    uint32_t slot;
  };

  template <>
  struct Binding<BufferHandle>
  {
    enum Format
    {
      FORMAT_UNSET,
      FORMAT_R32U,
      FORMAT_STRUCT,
    };
    BufferHandle value;
    uint32_t slot;
    Format format;
    bool isWritable; //true if this is a UAV, imageBuffer/texture, or SSBO
  };

  template <>
  struct Binding<TextureHandle>
  {
    enum Format
    {
      FORMAT_UNSET,
      FORMAT_R32U,
      FORMAT_RGBA8_UNORM,
      FORMAT_BGRA8_UNORM,
      FORMAT_RGBA16F,
      FORMAT_X24G8_UINT,
    };
    TextureHandle value;
    uint32_t slot;
    Format format;
    uint32_t mipLevel;
    bool isWritable; //true if this is a UAV, imageBuffer/texture, or SSBO
  };

  //////////////////////////////////////////////////////////////////////////
  // Draw State
  //////////////////////////////////////////////////////////////////////////

  struct DrawCallState
  {
    enum { MAX_TEXTURE_BINDINGS = 128, MAX_SAMPLER_BINDINGS = 16, MAX_BUFFER_BINDINGS = 128, MAX_CB_BINDINGS = 15 };
    enum SHADERS { SHADER_VERTEX, SHADER_HULL, SHADER_DOMAIN, SHADER_GEOMETRY, SHADER_PIXEL, SHADERS_COUNT };

    ShaderHandle shaders[SHADERS_COUNT];
    //If this state came from an IUserDefinedShaderSet this is the index of the permutation we are using in case the application needs it to find reflection data
    uint32_t     userDefinedShaderPermutationIndex[SHADERS_COUNT];

    //Each texture has a corresponding sampler to ease GL vs. DX porting
    Binding<TextureHandle> textures[SHADERS_COUNT][MAX_TEXTURE_BINDINGS];
    uint32_t textureBindingCount[SHADERS_COUNT];

    Binding<SamplerHandle> textureSamplers[SHADERS_COUNT][MAX_SAMPLER_BINDINGS];
    uint32_t textureSamplerBindingCount[SHADERS_COUNT];

    Binding<BufferHandle> buffers[SHADERS_COUNT][MAX_BUFFER_BINDINGS];
    uint32_t bufferBindingCount[SHADERS_COUNT];

    Binding<ConstantBufferHandle> constantBuffers[SHADERS_COUNT][MAX_CB_BINDINGS];
    uint32_t constantBufferBindingCount[SHADERS_COUNT];
   
    RenderState renderState;

    DrawCallState()
    { 
      memset(textureBindingCount, 0, sizeof(textureBindingCount));
      memset(textureSamplerBindingCount, 0, sizeof(textureSamplerBindingCount));
      memset(bufferBindingCount, 0, sizeof(bufferBindingCount));
      memset(constantBufferBindingCount, 0, sizeof(constantBufferBindingCount));
      memset(shaders, 0, sizeof(shaders));
      memset(userDefinedShaderPermutationIndex, 0, sizeof(userDefinedShaderPermutationIndex));
      memset(textures, 0, sizeof(textures));
      memset(textureSamplers, 0, sizeof(textureSamplers));
      memset(buffers, 0, sizeof(buffers));
      memset(constantBuffers, 0, sizeof(constantBuffers));
    }
  };

  //////////////////////////////////////////////////////////////////////////
  // Dispatch State
  //////////////////////////////////////////////////////////////////////////

  struct DispatchState
  {
    enum { MAX_TEXTURE_BINDINGS = 128, MAX_SAMPLER_BINDINGS = 16, MAX_BUFFER_BINDINGS = 128, MAX_CB_BINDINGS = 15 };

    ShaderHandle shader;

    //If this state came from an IUserDefinedShaderSet this is the index of the permutation we are using in case the application needs it to find reflection data
    uint32_t     userDefinedShaderPermutationIndex;

    //Each texture has a corresponding sampler to ease GL vs. DX porting
    Binding<TextureHandle> textures[MAX_TEXTURE_BINDINGS];
    uint32_t textureBindingCount;
    Binding<SamplerHandle> textureSamplers[MAX_SAMPLER_BINDINGS];
    uint32_t textureSamplerBindingCount;
    Binding<BufferHandle> buffers[MAX_BUFFER_BINDINGS];
    uint32_t bufferBindingCount;
    Binding<ConstantBufferHandle> constantBuffers[MAX_CB_BINDINGS];
    uint32_t constantBufferBindingCount;

    DispatchState() 
      : textureBindingCount(0)
      , textureSamplerBindingCount(0)
      , bufferBindingCount(0)
      , constantBufferBindingCount(0)
      , shader(NULL)
      , userDefinedShaderPermutationIndex(0)
    {
      memset(textures, 0, sizeof(textures));
      memset(textureSamplers, 0, sizeof(textureSamplers));
      memset(buffers, 0, sizeof(buffers));
      memset(constantBuffers, 0, sizeof(constantBuffers));
    }

  };

  struct ShaderResources
  {
    enum { MAX_TEXTURE_BINDINGS = 128, MAX_SAMPLER_BINDINGS = 16, MAX_CB_BINDINGS = 15, MAX_UAV_BINDINGS = 64 };
    
    uint32_t textureSlots[MAX_TEXTURE_BINDINGS];
    uint32_t textureCount;

    uint32_t samplerSlots[MAX_SAMPLER_BINDINGS];
    uint32_t samplerCount;

    uint32_t constantBufferSlots[MAX_CB_BINDINGS];
    uint32_t constantBufferCount;
    
    uint32_t unorderedAccessViewSlots[MAX_UAV_BINDINGS];
    uint32_t unorderedAccessViewCount;

    ShaderResources()
      : textureCount(0)
      , samplerCount(0)
      , constantBufferCount(0)
      , unorderedAccessViewCount(0)
    { 
      memset(textureSlots, 0, sizeof(textureSlots));
      memset(samplerSlots, 0, sizeof(samplerSlots));
      memset(constantBufferSlots, 0, sizeof(constantBufferSlots));
      memset(unorderedAccessViewSlots, 0, sizeof(unorderedAccessViewSlots));
    }
  };

}
GI_END_PACKING

#endif // GI_INTERFACETYPES_H_
