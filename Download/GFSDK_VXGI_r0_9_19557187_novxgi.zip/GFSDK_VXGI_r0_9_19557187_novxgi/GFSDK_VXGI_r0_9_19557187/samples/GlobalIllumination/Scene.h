/* 
* Copyright (c) 2012-2014, NVIDIA CORPORATION. All rights reserved. 
* 
* NVIDIA CORPORATION and its licensors retain all intellectual property 
* and proprietary rights in and to this software, related documentation 
* and any modifications thereto. Any use, reproduction, disclosure or 
* distribution of this software and related documentation without an express 
* license agreement from NVIDIA CORPORATION is strictly prohibited. 
*/ 

#pragma once

#include "assimp/scene.h"
#include "GI_Types.h"
#include "D3DHelper.h"
#include "d3d11.h"
#include <vector>
#include <map>

class Scene
{
protected:
    ID3D11Device*           m_pDevice;
    aiScene*                m_pScene;

    std::vector<VXGI::Box3f>      m_MeshBounds;
    VXGI::Box3f                   m_SceneBounds;

    std::string             m_ScenePath;

    Buffer                  m_IndexBuffer;

    Buffer                  m_PositionsBuffer;
    Buffer                  m_CoordinatesBuffer;
    Buffer                  m_NormalsBuffer;
    Buffer                  m_TangentsBuffer;
    Buffer                  m_BitangentsBuffer;

    std::vector<UINT>       m_IndexOffsets;
    std::vector<UINT>       m_VertexOffsets;

    std::vector<Texture2D>  m_DiffuseTextures;
    std::vector<Texture2D>  m_SpecularTextures;
    std::vector<Texture2D>  m_NormalsTextures;
    std::vector<Texture2D>  m_OpacityTextures;
    std::vector<Texture2D>  m_EmissiveTextures;

    std::vector<VXGI::Vector3f>   m_DiffuseColors;
    std::vector<VXGI::Vector3f>   m_SpecularColors;
    std::vector<VXGI::Vector3f>   m_EmissiveColors;

    std::vector<UINT>       m_MeshToSceneMapping;
    std::map<std::string, Texture2D*> m_LoadedTextures;

    void LoadTextureFromFile(Texture2D& texture, const char* name);
    
public:
    Scene()
        : m_pScene(NULL)
        , m_pDevice(NULL)
    {}
    virtual ~Scene()
    {
        Release();
        ReleaseResources();
    }

    HRESULT Load(const char* fileName, UINT flags = 0);
    HRESULT InitResources(ID3D11Device* pDevice);
    void UpdateBounds();
    void Release();
    void ReleaseResources();

    const char* GetScenePath() { return m_ScenePath.c_str(); }

    UINT GetMeshesNum() const { return m_pScene ? m_pScene->mNumMeshes : 0; }

    VXGI::Box3f GetSceneBounds() const;

    ID3D11Buffer* GetIndexBuffer(UINT meshID, OUT UINT &offset) const;
    ID3D11Buffer* GetPositionBuffer(UINT meshID, OUT UINT &offset) const;
    ID3D11Buffer* GetTexCoordinateBuffer(UINT meshID, OUT UINT &offset) const;
    ID3D11Buffer* GetNormalBuffer(UINT meshID, OUT UINT &offset) const;
    ID3D11Buffer* GetTangentBuffer(UINT meshID, OUT UINT &offset) const;
    ID3D11Buffer* GetBitangentBuffer(UINT meshID, OUT UINT &offset) const;

    ID3D11ShaderResourceView* GetTextureSRV(aiTextureType type, UINT meshID) const;
    VXGI::Vector3f GetColor(aiTextureType type, UINT meshID) const;
    int GetMaterialIndex(UINT meshID) const;

    UINT GetMeshIndicesNum(UINT meshID) const;
    VXGI::Box3f GetMeshBounds(UINT meshID) const;
};